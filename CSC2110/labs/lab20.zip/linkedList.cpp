#include "linkedList.h"

bool LinkedList::isEmpty() const
{
	if (first == nullptr && last == nullptr)
		return 1;
	else
		return 0;
}

int LinkedList::getSize() const
{
	return size;
}

void LinkedList::display() const
{
	NodeType* current;
	current = first;

	while (current != nullptr) {
		cout << current->data.getFirstName() << " " << current->data.getLastName() << endl;
		current = current->next;
	}
}

void LinkedList::addLast(Student studentData)
{
	NodeType* newNode = new NodeType;
	newNode->data = studentData;

	if (isEmpty()) {
		first = newNode;
		last = newNode;
	}
	else {
		last->next = newNode;
		last = newNode;
	}

	size++;
}

LinkedList::LinkedList()
{
	size = 0;
	first = nullptr;
	last = nullptr;

}

#pragma once
#include "student.h"

class NodeType {
public:
	Student data;
	NodeType* next;

	NodeType();


};
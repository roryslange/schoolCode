#include "node.h"

NodeType::NodeType()
{
	next = nullptr;
}

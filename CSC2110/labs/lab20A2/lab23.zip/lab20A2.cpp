// lab20A2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "student.h"
#include "node.h"
#include "linkedList.h"
using namespace std;


int main()
{
	Student s1("Ira", "Glass");
	Student s2("Adam", "Driver");
	Student s3("Hasan", "Piker");
	

	LinkedList list;

	list.addFirst(s1);
	list.addFirst(s2);
	list.addFirst(s3);

	

	cout << "linked list app!\n";
	cout << "------------------\n\n";

	list.display();

	cout << "\nremove first\n";
	list.deleteFirst();
	list.display();

	cout << "\nremove last\n";
	list.deleteLast();
	list.display();

	cout << "\nremove last\n";
	list.deleteLast();
	list.display();


	return 0;
}


//==========================================================
//
// Title: Implicit Data Type Conversions - cin
// Description:
//   This C++ console application shows implicit data type 
// conversions when using cin to read from the keyboard.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int iNum;
  double rNum;
  string str;
  char chr;

  // Show application header
  cout << "Welcome to Implicit Data Type Conversions - cin" 
    << endl;
  cout << "-----------------------------------------------" 
    << endl << endl;

  // Prompt for and get an integer
  cout << "Enter an integer: ";
  cin >> iNum;
  cout << "Integer is " << iNum << endl << endl;

  // Prompt for and get a real number
  cout << "Enter a real number: ";
  cin >> rNum;
  cout << "Real number is " << rNum << endl << endl;

  // Prompt for and get a string
  cout << "Enter a string: ";
  cin >> str;
  cout << "String is " << str << endl << endl;

  // Prompt for and get a character
  cout << "Enter a character: ";
  cin >> chr;
  cout << "Character is " << chr << endl;

  // Show application close
  cout << "\nEnd of Implicit Data Type Conversions - cin" 
    << endl;

}

//==========================================================
//
// Title: Pointers to Arrays of structs
// Description:
//    This C++ console application demonstrates pointers to
// arrays of structs.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================

const int COLFMT1 = 16;
const int COLFMT2 = 8;
const int COLFMT3 = 22;
const int ARRAY_SIZE = 4;

struct employee
{
  int ID;
  string firstName;
  string lastName;
  double hourlyRate;
};

//==========================================================
// setEmployeeData
//==========================================================
void setEmployeeData(employee employees[], int i,
  int ID, string first, string last, double rate)
{
  employees[i].ID = ID;
  employees[i].firstName = first;
  employees[i].lastName = last;
  employees[i].hourlyRate = rate;
}

//==========================================================
// printMemoryMap
//==========================================================
void printMemoryMap(employee employees[], int count)
{

  // Print column headers
  cout << "\nArray memory map" << endl;
  cout << setw(COLFMT2) << right << "Index"
    << setw(COLFMT3) << right << "Address (hex)"
    << setw(COLFMT2) << right << "Bytes"
    << endl;

    // Loop to print address data
  for (int i = 0; i < count; i++)
    cout << setw(COLFMT2) << right << i
      << setw(COLFMT3) << right << &employees[i]
      << setw(COLFMT2) << right 
      << (long(&employees[i+1]) - long(&employees[i])) 
      << endl;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  employee employees[ARRAY_SIZE];
  int count = 0;

  // Show application header
  cout << "Welcome to Pointers to Arrays of structs" 
    << endl;
  cout << "----------------------------------------" 
    << endl;

  // Format financial numbers
  cout << fixed << setprecision(2);

  //Set employee 1 from assigned values
  setEmployeeData(employees, count, 513, "Sam",
    "Stocker", 14.75);
  count = count + 1;

  // Set employee 2 from assigned values
  setEmployeeData(employees, count, 274, "Rita",
    "Retailer", 16.30);
  count = count + 1;

  // Set employee 3 from assigned values
  setEmployeeData(employees, count, 489, "Wendy",
    "Warehouser", 12.60);
  count = count + 1;

  // Set employee 4 from assigned values
  setEmployeeData(employees, count, 634, "Ben",
    "Biller", 15.17);
  count = count + 1;

  // Print column headers
  cout << setw(COLFMT1) << left << "ID"
    << setw(COLFMT1) << left << "First Name"
    << setw(COLFMT1) << left << "Last Name"
    << setw(COLFMT1) << right << "Hourly Rate ($)"
    << endl;

  // Loop to print employee information by index
  cout << "\nEmployee information (by index)" << endl;
  for (int i = 0; i < count; i++)
    cout << setw(COLFMT1) << left << employees[i].ID
      << setw(COLFMT1) << left << employees[i].firstName
      << setw(COLFMT1) << left << employees[i].lastName
      << setw(COLFMT1) << right << employees[i].hourlyRate
      << endl;

  // Loop to print employee information by pointer and arrow
  // operator
  // &employees and &employees[0] are identical
  cout 
    << "\nEmployee information (by pointer and arrow "
    << "operator)" << endl;
  for (employee *ptr = &employees[0]; 
       ptr < &employees[count]; 
       ptr++)
    cout << setw(COLFMT1) << left << ptr->ID
      << setw(COLFMT1) << left << ptr->firstName
      << setw(COLFMT1) << left << ptr->lastName
      << setw(COLFMT1) << right << ptr->hourlyRate
      << endl;

  // Loop to print employee information by pointer and dot
  // operator
  // &employees and &employees[0] are identical
  cout 
    << "\nEmployee information (by pointer and dot "
    << "operator)" << endl;
  for (employee *ptr = &employees[0]; 
       ptr < &employees[count]; 
       ptr++)
    cout << setw(COLFMT1) << left << (*ptr).ID
        << setw(COLFMT1) << left << (*ptr).firstName
        << setw(COLFMT1) << left << (*ptr).lastName
        << setw(COLFMT1) << right << (*ptr).hourlyRate
        << endl;

  // Print memory maps
  printMemoryMap(employees, count);

  // Show application close
  cout << "\nEnd of Pointers to Arrays of structs"
    << endl;

}
 
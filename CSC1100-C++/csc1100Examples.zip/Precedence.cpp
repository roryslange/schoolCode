//==========================================================
//
//  Title: Precedence
//  Description:
//    This C++ console application demonstrates precedence.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  bool flag1;
  bool flag2 = false;
  bool flag3 = true;

  // Show application header
  cout << "Welcome to Precedence" << endl;
  cout << "---------------------" << endl;
  cout << "0 = false" << endl;
  cout << "1 = true" << endl << endl;

  // Print flag values before assignment statements
  cout << "flag values before assignment statements" 
    << endl;
  //cout << "flag1: " << flag1 << endl;  
    // Cannot print unitialized variable
  cout << "flag2: " << flag2 << endl;
  cout << "flag3: " << flag3 << endl;

  // Do assignments
  flag1 = !flag2 && -3 + 4 * 2 - 6 / 5 >= 7 || flag3;
  flag2 = 4 % 3 + 2 * 5 / 6 + -8 < 0;
  flag3 = !flag1 || flag2 && flag3;

  // Print flag values after assignment statements
  cout << "\nflag values after assignment statements" 
    << endl;
  cout << "flag1: " << flag1 << endl;
  cout << "flag2: " << flag2 << endl;
  cout << "flag3: " << flag3 << endl;

  // Show application close
  cout << "\nEnd of Precedence" << endl;

}

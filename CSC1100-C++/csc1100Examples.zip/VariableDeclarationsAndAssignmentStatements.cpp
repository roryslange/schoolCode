//==========================================================
//
// Title: Variable Declarations and Assignment Statements
// Description:
//   This C++ console application declares variables and 
// assigns values to them.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables, some with starting values
  int iNum;
  double rNum;
  string str;
  char ltr1;
  char ltr2;
  bool flag = true;
  unsigned int iUnNum = 78;
  cout << "Variables declared." << endl << endl;

  // Show application header
  cout << "Welcome to Variable Declarations and Assignment "
    << "Statements" << endl;
  cout << "------------------------------------------------"
    << "----------" << endl << endl;

  // Assign values
  iNum = 22;
  rNum = 11.55;
  str = "Abe Lincoln";
  ltr1 = 'Q';
  ltr2 = 33;
  cout << "Values assigned to variables." << endl;

  // Print values
  cout << "\nVariable names (data type) and values" << endl;
  cout << "iNum (int):            " << iNum << endl;
  cout << "rNum (double):         " << rNum << endl;
  cout << "str (string):          " << str << endl;
  cout << "ltr1 (char):           " << ltr1 << endl;
  cout << "ltr2 (char):           " << ltr2 << endl;
  cout << "flag (bool):           " << flag 
    << " (0 = false, not 0 = true)" << endl;
  cout << "iUnNum (unsigned int): " << iUnNum << endl;

  // Show application close
  cout << "\nEnd of Variable Declarations and Assignment "
    << "Statements" << endl;

}

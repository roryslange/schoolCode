//==========================================================
//
// Title: Text file input - one token per read
// Description:
//   This C++ console application demonstrates reading one 
// token at a time from a text file.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  ifstream inFile;
  int lineCount;
  int tokenCount;
  string line;
  string model;
  int year;
  double cost;

  // Declare constants
  const string INPUT_FILE_NAME = "CarsIn.txt";
  const int COLFMT1 = 11;
  const int COLFMT2 = 10;
  const int COLFMT3 = 19;

  // Format real numbers
  cout << setprecision(2) << fixed;
  
  // Show application header
  cout << "Welcome to Text File Input - One Token Per Read" 
    << endl;
  cout << "-----------------------------------------------" 
    << endl << endl;

  // Attempt to open input file
  inFile.open(INPUT_FILE_NAME);
  if (!inFile.is_open())
    cout << "Error: unable to open file '" 
    << INPUT_FILE_NAME << "'." << endl << endl;
  else 
  {

    // Print read messsage
    cout << "Reading tokens from file '" << INPUT_FILE_NAME
      << "' ..." << endl << endl;

    // Read and echo header line
    getline(inFile, line);
    cout << line << endl;
    
    // Loop to read from input file
    lineCount = 1;
    tokenCount = 0;
    while (inFile.good())
    {
      inFile >> model;
      inFile >> year;
      inFile >> cost;
      cout << setw(COLFMT1) << left << model
        << setw(COLFMT2) << right << year
        << setw(COLFMT3) << right << cost
        << endl;
      lineCount = lineCount + 1;
      tokenCount = tokenCount + 3;
    }

    // Close input file
    inFile.close();
    cout << endl << lineCount << " line(s) and " 
      << tokenCount << " token(s) read from file '"
      << INPUT_FILE_NAME << "'." << endl << endl;

  }

  // Show application close
  cout << "End of Text File Input - One Token Per Read" 
    << endl;

}

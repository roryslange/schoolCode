//==========================================================
//
// Title: Implicit And Explicit Casting
// Description:
//   This C++ console application shows both implicit and
// explicit casting.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int i = 200;
  int j = 48;
  double r = 7.2;
  char c;

  // Show application header
  cout << "Welcome to Implicit And Explicit Casting" 
    << endl;
  cout << "----------------------------------------" 
    << endl << endl;

  // Implicit cast from integer to real
  // i is integer data type but is cast to real data type
  // so that it may be stored in real variable.
  r = i;
  cout << "Implicit cast" << endl;
  cout << "r: " << r << endl << endl;

  // No explicit cast from integer to real
  // Both i and j are integer data types so divsion operator
  // gives integer result before stored in real variable
  r = i / j;
  cout << "No explicit cast from integer to real" << endl;
  cout << "r: " << r << endl << endl;

  // Explicit cast from integer to real
  r = (double) i / j;
  // Both i and j are integer data types so (double) 
  // temporarily casts i to real data type so divsion 
  // operator gives real result before stored in real 
  // variable
  cout
    << "With explicit cast from integer to real using (double)" 
    << endl;
  cout << "r: " << r << endl << endl;

  // Explicit cast from integer to char using (char)
  c = (char) i;
  cout
    << "With explicit cast from integer to char using (char)"
    << endl;
  cout << "i: " << i << endl;
  cout << "c: " << c << endl;

  // Show application close
  cout << "\nEnd of Implicit And Explicit Casting" << endl;

}

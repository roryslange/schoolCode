//==========================================================
//
// Title: Programmer Library Header
// Description:
//   This C++ header file is paired with an implementation
// file of the same name, and may be included in any C++ 
// application.
//
//==========================================================
#ifndef PROGRAMMER_LIBRARY_H
#define PROGRAMMER_LIBRARY_H

#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Function prototypes
//==========================================================
double salesTax(string state, double subtotal);
string upperCase(string str);

#endif PROGRAMMER_LIBRARY_H

//==========================================================
//
// Title: Implicit Data Type Conversions - Assignment
// Description:
//   This C++ console application shows implicit data type 
// conversions when executing the assignment statement.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  char letter;
  int iNum1;
  int iNum2;
  int iNum3;
  double rNum1;
  double rNum2;
  double rNum3;
  string str1;
  string str2;
  string str3;
  char ltr1;
  char ltr2;
  char ltr3;
  
  // Show application header
  cout << "Welcome to Implicit Data Type Conversions - "
    << "Assignment" << endl;
  cout << "---------------------------------------------"
    << "---------" << endl << endl;

  // Casts to int
  iNum1 = 45.3;          // double -> int; truncates number
  //iNum2 = "45";        // string -> int; cannot do this
  //iNum2 = (int) "45";  // cast string -> int; cannot do this
  iNum3 = '4';           // char -> int
  cout << "Casts to int" << endl;
  cout << "double-to-int: " << iNum1 << endl;
  cout << "char-to-int:   " << iNum3 << endl;

  // Casts to double
  rNum1 = 45;               // int -> double
  //rNum2 = "45";           // string -> double; cannot do this
  //rNum2 = (double) "45";  // cast string -> double; cannot do this
  rNum3 = '4';              // char -> double
  cout << "\nCasts to double" << endl;
  cout << "int-to-double:  " << rNum1 << endl;
  cout << "char-to-double: " << rNum3 << endl;

  // Casts to string
  str1 = 37;    // int -> char -> string
  str2 = 35.8;  // double -> int -> char -> string
  str3 = '4';   // char -> string
  cout << "\nCasts to string" << endl;
  cout << "int-to-string:    " << str1 << endl;
  cout << "double-to-string: " << str2 << endl;
  cout << "char-to-string:   " << str3 << endl;

  // Casts to char
  ltr1 = 37;            // int -> char
  ltr2 = 35.8;          // double -> int -> char
  //ltr3 = "4";         // string -> char; cannot do this
  //ltr3 = (char) "4";  // cast string -> char; cannot do this
  cout << "\nCasts to char" << endl;
  cout << "int-to-char:    " << ltr1 << endl;
  cout << "double-to-char: " << ltr2 << endl;

  // Show application close
  cout << "\nEnd of Implicit Data Type Conversions - "
    << "Assignment" << endl;

}

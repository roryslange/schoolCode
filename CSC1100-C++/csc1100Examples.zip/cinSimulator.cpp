//==========================================================
//
// Title: cin Simulator
// Description:
//   This C++ console application simulates these input 
// functions:
//   cin
//   cin.get()
//   getline()
//   cin.peek()
//   cin.ignore()
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int BUFFER_SIZE = 20;
const int SCAN_COUNT = 100;
const int TAB_CODE = 9;
const char CHAR_SET[] = { ' ','T','R','a','b','c','d','e' };

//==========================================================
// menuOption
//==========================================================
int menuOption()
{

  // Declare variables
  int option;

  // Show prompt menu and get option
  cout << endl;
  cout << "Prompt and Read Menu" << endl;
  cout << "0 - Clear input buffer" << endl;
  cout << "1 - Have app enter input" << endl;
  cout << "2 - Prompt user for input" << endl;
  cout << "3 - Call cin" << endl;
  cout << "4 - Call cin.get(chr)" << endl;
  cout << "5 - Call getline(cin, token)" << endl;
  cout << "6 - Call cin.peek()" << endl;
  cout << "7 - Call cin.ignore(100, '\\n')" << endl;
  cout << "8 - Show input buffer key" << endl;
  cout << "9 - Exit" << endl;
  cout << "Enter an option: ";
  cin >> option;

  // Return option
  return option;

}

//==========================================================
// addBuffer
//==========================================================
void addBuffer(string input, char buffer[], int &lastPtr)
{

  // Declare variables
  int i;

  // Loop to populate buffer
  lastPtr = lastPtr + 1;
  i = 0;
  while (lastPtr < BUFFER_SIZE && i < input.length())
  {

    // Test whether to convert TAB character to 'T'
    if ((int) input[i] == TAB_CODE)
      buffer[lastPtr] = 'T';
    else
      buffer[lastPtr] = input[i];
    lastPtr = lastPtr + 1;
    i = i + 1;

  }

  // Test if buffer limit reached
  if (lastPtr == BUFFER_SIZE)
  {
    lastPtr = lastPtr - 1;
    cout << "Input buffer full - could not add all entered characters."
      << endl;
  }
  buffer[lastPtr] = 'R';

}

//==========================================================
// removeFromBuffer
//==========================================================
void removeFromBuffer(int charCount, char buffer[], int &lastPtr)
{

  // Test if token is entire buffer
  if (charCount == (lastPtr + 1))
    lastPtr = -1;
  else
  {

    // Loop to remove token from buffer
    for (int i = 0; i <= (lastPtr - charCount); i++)
      buffer[i] = buffer[i + charCount];

    // Move buffer pointer
    lastPtr = lastPtr - charCount;

  }

}

//==========================================================
// setBuffer
//==========================================================
void setBuffer(char buffer[], int& lastPtr)
{

  // Declare variables
  char c;

  // Initialize random number generator
  srand(time(0));

  // Loop to populate buffer
  lastPtr = lastPtr + 1;
  c = CHAR_SET[rand() % sizeof(CHAR_SET)];
  while (lastPtr < BUFFER_SIZE && c != 'R')
  {
    buffer[lastPtr] = c;
    lastPtr = lastPtr + 1;
    c = CHAR_SET[rand() % sizeof(CHAR_SET)];
  }

  // Test if buffer limit reached
  if (lastPtr == BUFFER_SIZE)
    lastPtr = lastPtr - 1;
  buffer[lastPtr] = 'R';

}

//==========================================================
// showBufferKey
//==========================================================
void showBufferKey()
{
  cout << "\nInput buffer key" << endl;
  cout << "  N    Input buffer pointer; next character to be read" << endl;
  cout << "|   |  Blank character" << endl;
  cout << "| T |  Tab character" << endl;
  cout << "| R |  Enter/return character" << endl;
  cout << "| * |  All other characters" << endl;
}

//==========================================================
// showBuffer
//==========================================================
void showBuffer(char buffer[], int lastPtr)
{

  // Loop to show input buffer numbers
  cout << "\nInput buffer" << endl;
  if (lastPtr == -1)
    cout << "Buffer is EMPTY" << endl;
  else
  {

    // Loop to show input buffer indexes
    for (int i = 0; i <= lastPtr; i++)
      if (i < 10)
        cout << "  " << i << " ";
      else
        cout << " " << i << " ";
    cout << endl;

    // Loop to show input buffer contents
    for (int i = 0; i <= lastPtr; i++)
      cout << "| " << buffer[i] << " ";
    cout << "|" << endl;

    // Show input buffer pointer
    cout << "  N" << endl;

  }

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  char buffer[BUFFER_SIZE];
  int lastPtr;  // Pointer to last character in buffer
  int charCount;
  string input;
  int option;
  string token;

  // Show application header
  cout << "Welcome to the cin Simulator" << endl;
  cout << "----------------------------" << endl;
    
  // Show buffer key and buffer
  lastPtr = -1;
  showBufferKey();
  showBuffer(buffer, lastPtr);
  
  // Loop to process menu options
  option = menuOption();
  while (option != 9)
  {

    // Process clear input buffer
    if (option == 0)
    {
      lastPtr = -1;
      cout << "Input buffer cleared." << endl;
    }

    // Process app entering input
    else if (option == 1)
    {
      if (lastPtr == (BUFFER_SIZE - 1))
        cout << "Input buffer full - no room to add characters."
          << endl;
      else
      {
        charCount = lastPtr;
        setBuffer(buffer, lastPtr);
        charCount = lastPtr - charCount;
        cout << "App entered " << charCount << " random "
          << (charCount == 1 ? "character." : "characters.")
          << endl;
      }
    }

    // Process user entering input
    else if (option == 2)
    {
      if (lastPtr == (BUFFER_SIZE - 1))
        cout << "Input buffer full - no room to add characters."
        << endl;
      else
      {
        cout << "Enter some characters: ";
        cin.ignore(100, '\n');
        getline(cin, input);
        charCount = lastPtr;
        addBuffer(input, buffer, lastPtr);
        charCount = lastPtr - charCount;
        cout << "User entered " << charCount 
          << (charCount == 1 ? " character." : " characters.")
          << endl;
      }
    }

    // Process cin
    else if (option == 3)
    {

      // Test if any characters to get
      if (lastPtr == -1)
        cout << "\nInput buffer is empty - there is nothing to get."
        << endl;
      else
      {

        // Loop to scan past whitespace characters
        token = "";
        charCount = 0;
        while (charCount <= lastPtr &&
          (buffer[charCount] == ' ' ||
            buffer[charCount] == 'T' ||
            buffer[charCount] == 'R'))
        {
          token = token + buffer[charCount];
          charCount = charCount + 1;
        }

        // Show message and update buffer
        if (charCount == 0)
          cout << "\nThere were no leading whitespace characters to scan past."
            << endl;
        else
        {
          cout << "\ncin scanned past '" << token
            << "' and removed token from input buffer."
            << endl;
          removeFromBuffer(charCount, buffer, lastPtr);
        }

        // Loop to read non-whitespace characters
        token = "";
        charCount = 0;
        while (charCount <= lastPtr &&
          (buffer[charCount] != ' ' &&
            buffer[charCount] != 'T' &&
            buffer[charCount] != 'R'))
        {
          token = token + buffer[charCount];
          charCount = charCount + 1;
        }

        // Show message and update buffer
        cout << "cin read '" << token
           << "', stored it, and removed token from input buffer."
          << endl;
        removeFromBuffer(charCount, buffer, lastPtr);

      }

    }

    // Process cin.get
    else if (option == 4)
    {

    // Test if any character to get
    if (lastPtr == -1)
        cout << "\nInput buffer is empty - there is nothing to get."
        << endl;
      else
      {

        // Show message
        cout << "\ncin.get(chr) read '" << buffer[0]
          << "', stored it, and removed character from input buffer."
          << endl;

        // Loop to remove character from buffer
        for (int i = 0; i <= (lastPtr - 1); i++)
          buffer[i] = buffer[i + 1];

        // Move buffer pointer
        lastPtr = lastPtr - 1;

      }

    }

    // Process getline
    else if (option == 5)
    {

      // Test if any characters to get
      if (lastPtr == -1)
        cout << "\nInput buffer is empty - there is nothing to get."
          << endl;
      else
      {

        // Loop to read characters until 'R'
        token = "";
        charCount = 0;
        while (charCount <= lastPtr &&
          buffer[charCount] != 'R')
        {
          token = token + buffer[charCount];
          charCount = charCount + 1;
        }
        token = token + buffer[charCount];
        charCount = charCount + 1;

        // Show message and update buffer
        cout << "\ngetline(cin, token) read '" << token
          << "', stored all but trailing 'R', and removed token from input buffer."
          << endl;
        removeFromBuffer(charCount, buffer, lastPtr);

      }

    }

    // Process cin.peek
    else if (option == 6)
    {
      if (lastPtr == -1)
        cout << "\nInput buffer is empty - there is nothing to peek."
        << endl;
      else
        cout << "\ncin.peek() read '" << buffer[0]
          << "' but did not remove character from input buffer." 
          << endl;
    }

    // Process cin.ignore
    else if (option == 7)
    {

      // Test if any characters to ignore
      if (lastPtr == -1)
        cout << "\nInput buffer is empty - there is nothing to ignore."
        << endl;
      else
      {

        // Loop to read characters until 'R'
        token = "";
        charCount = 0;
        while (charCount <= lastPtr &&
          buffer[charCount] != 'R')
        {
          token = token + buffer[charCount];
          charCount = charCount + 1;
        }
        token = token + buffer[charCount];
        charCount = charCount + 1;

        // Show message and update buffer
        cout << "\ncin.ignore(100, '\\n') read '" << token
          << "' and removed token from input buffer."
          << endl;
        removeFromBuffer(charCount, buffer, lastPtr);

      }

    }

      // Process help
    else if (option == 8)
      showBufferKey();

    // Handle unknown option
    else
    {
      cout << "Invalid option of '" << option << "'." << endl;
    }

    // Show buffer
    showBuffer(buffer, lastPtr);

    // Get next option
    option = menuOption();

  }

  // Show application close
  cout << "\nEnd of the cin Simulator" << endl;

}

//==========================================================
//
// Title: Escape Sequences
// Description:
//   This C++ console application shows the most useful escape 
// sequences:
//   \" - print the double quote character
//   \\ - print the backslash character
//   \n - new line
//   \t - tab
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Show application header
  cout << "Welcome to Escape Sequences" << endl;
  cout << "---------------------------" << endl << endl;

  // Use \\ escape sequence
  cout << "Escape sequence \\\\" << endl;
  cout << "Include a backslash in the output: \\" << endl;

  // Use \" escape sequence
  cout << endl;
  cout << "Escape sequence \\\"" << endl;
  cout << "Include a \"double quote\" in the output." 
    << endl;

  // Use \a escape sequence
  cout << endl;
  cout << "Escape sequence \\a" << endl;
  cout << "\aSound a bell." << endl;

  // Use \b escape sequence
  cout << endl;
  cout << "Escape sequence \\b" << endl;
  cout << "Backspace cursor: password";
  cout << "\b\b\b\b\b\b\b\b";
  cout << "********" << endl;

  // Use \n escape sequence
  cout << endl;
  cout << "Escape sequence \\n" << endl;
  cout << endl;
  cout << "A line return using endl." << endl;
  cout << "A line return using backslash-n.\n";
  cout << endl;
  cout << "A " << endl << "line with " << endl 
    << "multiple " << endl << "endl's." << endl;
  cout << endl; 
  cout << "\n";
  cout << "A \nline with \nmultiple \nbackslash-n's.\n";

  // Use \t escape sequence
  cout << endl;
  cout << "Escape sequence \\t" << endl;
  cout << "The nth tab stop is at column 8n+1" << endl;
  cout << endl;
  cout << "123456789012345678901234567890123456789012345678901234567890" << endl;
  cout << "Stops:\t#\t#\t#\t#\t#\t#\t#" << endl;
  cout << endl;
  cout << "Team\t\tWins\tLosses" << endl;
  cout << "Detroit\t\t90\t60" << endl;
  cout << "Chicago\t\t87\t63" << endl;
  cout << "Cleveland\t82\t68" << endl;
  cout << "Kansas City\t73\t79" << endl;
  cout << endl;
  cout << "Stops:\t#\t#\t#\t#\t#\t#\t#" << endl;
  cout << "123456789012345678901234567890123456789012345678901234567890" << endl;

  // Show application close
  cout << "\nEnd of Escape Sequences" << endl;

}

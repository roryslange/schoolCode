//==========================================================
//
// Title: Arrays - Multi-Dimensional
// Description:
//   This C++ console application demonstrates 
// multi-dimensional arrays.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global variables
//==========================================================
const int ROW_SIZE = 3;
const int COL_SIZE = 6;
const int DEPTH_SIZE = 2;
const int COLFMT1 = 6;
const int COLFMT2 = 10;
const int COLFMT3 = 3;
const int COLFMT4 = 20;

//==========================================================
// randomize2DArray
//==========================================================
void randomize2DArray(string heading, 
  int arr[ROW_SIZE][COL_SIZE], int upperLimit)
{

  // Initialize random number generator
  srand(time(NULL));

  // Loop to generate and store random numbers in array
  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COL_SIZE; j++)
      arr[i][j] = rand() % upperLimit + 1;
  cout << "\nRandomized numbers in the range 1 to " 
    << upperLimit << " stored in array " << heading << endl;

}

//==========================================================
// randomize3DArray
//==========================================================
void randomize3DArray(string heading,
  int arr[ROW_SIZE][COL_SIZE][DEPTH_SIZE], int upperLimit)
{

  // Initialize random number generator
  srand(time(NULL));

  // Loop to generate and store random numbers in array
  for (int i = 0; i < ROW_SIZE; i++)
    for (int j = 0; j < COL_SIZE; j++)
      for (int k = 0; k < DEPTH_SIZE; k++)
        arr[i][j][k] = rand() % upperLimit + 1;
  cout << "\nRandomized numbers in the range 1 to "
    << upperLimit << " stored in array " << heading << endl;

}

//==========================================================
// print2DArray
//==========================================================
void print2DArray(string heading, 
  int arr[ROW_SIZE][COL_SIZE])
{

  // Loop to print array numbers
  cout << "\n" + heading << endl;
  cout << "Array dimensions: " 
    << ROW_SIZE << "x" 
    << COL_SIZE << endl;
  cout << setw(COLFMT1) << right << "";
  for (int j = 0; j < COL_SIZE; j++)
    cout << setw(COLFMT1) << right << j;
  cout << endl;
  for (int i = 0; i < ROW_SIZE; i++)
  {
    cout << setw(COLFMT1) << right << i;
    for (int j = 0; j < COL_SIZE; j++)
      cout << setw(COLFMT1) << right << arr[i][j];
    cout << endl;
  }

}

//==========================================================
// print3DArray
//==========================================================
void print3DArray(string heading,
  int arr[ROW_SIZE][COL_SIZE][DEPTH_SIZE])
{

  // Loop to print array numbers
  cout << "\n" + heading << endl;
  cout << "Array dimensions: " 
    << ROW_SIZE << "x"
    << COL_SIZE << "x" 
    << DEPTH_SIZE << endl;
  cout << setw(COLFMT2) << right << "";
  for (int j = 0; j < COL_SIZE; j++)
    cout << setw(COLFMT2) << right << j;
  cout << endl;
  for (int i = 0; i < ROW_SIZE; i++)
  {
    cout << setw(COLFMT2) << right << i;
    for (int j = 0; j < COL_SIZE; j++)
    {
      cout << setw(COLFMT3) << right << "(";
      for (int k = 0; k < DEPTH_SIZE; k++)
        cout << setw(COLFMT3) << right << arr[i][j][k];
      cout << ")";
    }
    cout << endl;
  }

}

//==========================================================
// main
//==========================================================
int main()
{
  
  // Declare two-dimensional arrays

  int arr1_2D[3][6];  
    // Use integers for array dimensions

  int arr2_2D[ROW_SIZE][COL_SIZE]; 
    // Use constants for array dimensions

  int arr3_2D[ROW_SIZE][COL_SIZE] =
  {
    { 12, 29, 11, 35, 17, 77 },
    { 25, 25, 13, 45, 87, 88 },
    { 11, 18, 14, 31, 94, 84 }
  };
    // Use initializer list

  int arr4_2D[ROW_SIZE][COL_SIZE] =
  {
    { 12, 29 },
    { 25, 25, 13},
    { 11, 18, 14, 31 }
  };
    // Use partial initializer list

  // Declare three-dimensional array

  int arr5_3D[ROW_SIZE][COL_SIZE][DEPTH_SIZE];  
    // Use constants for array dimensions

  // Show application header
  cout << "Welcome to Arrays - Multi-Dimensional" << endl;
  cout << "-------------------------------------" << endl;

  // Place random numbers in each array
  randomize2DArray("arr1_2D", arr1_2D, 10);
  randomize2DArray("arr2_2D", arr2_2D, 100);
  randomize3DArray("arr5_3D", arr5_3D, 100);

  // Print numbers in each array
  print2DArray("arr1_2D values", arr1_2D);
  print2DArray("arr2_2D values", arr2_2D);
  print2DArray("arr3_2D values", arr3_2D);
  print2DArray("arr4_2D values", arr4_2D);
  print3DArray("arr5_3D values", arr5_3D);

  // Print array addresses
  cout << "\nArray info" << endl;
  cout << setw(COLFMT4) << left << "Name" 
    << setw(COLFMT4) << left << "Address (hex)" 
    << setw(COLFMT4) << left << "Size" 
    << endl;

  cout << setw(COLFMT4) << left << "arr1_2D"
    << setw(COLFMT4) << left << arr1_2D 
    << setw(COLFMT4) << left
    << sizeof(arr1_2D) / sizeof(int) << endl;

  cout << setw(COLFMT4) << left << "arr2_2D"
    << setw(COLFMT4) << left << arr2_2D 
    << setw(COLFMT4) << left
    << sizeof(arr2_2D) / sizeof(int) << endl;

  cout << setw(COLFMT4) << left << "arr3_2D"
    << setw(COLFMT4) << left << arr3_2D 
    << setw(COLFMT4) << left
    << sizeof(arr3_2D) / sizeof(int) << endl;

  cout << setw(COLFMT4) << left << "arr4_2D"
    << setw(COLFMT4) << left << arr4_2D
    << setw(COLFMT4) << left
    << sizeof(arr4_2D) / sizeof(int) << endl;

  cout << setw(COLFMT4) << left << "arr5_3D"
    << setw(COLFMT4) << left << arr5_3D
    << setw(COLFMT4) << left
    << sizeof(arr5_3D) / sizeof(int) << endl;

  // Show application close
  cout << "\nEnd of Arrays - Multi-Dimensional" << endl;

}

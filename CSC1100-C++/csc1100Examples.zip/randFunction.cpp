//==========================================================
//
// Title: rand Function
// Description:
//   This C++ console application demonstrates the rand 
// function.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT = 8;

  // Declare variables
  int numbers;
  int min;
  int max;

  // Show application header
  cout << "Welcome to rand Function" << endl;
  cout << "------------------------" << endl << endl;

  // Prompt user for and get number of random numbers
  cout << "Random numbers between 0 and " << RAND_MAX 
    << endl;
  cout << "Enter number of randoms to generate: ";
  cin >> numbers;

  // Loop to create random numbers without randomizing 
  // generator
  cout << "\n\"Random-number\" generation WITHOUT "
    << "randomizing generator" << endl;
  cout << setw(COLFMT) << right << "Index"
    << setw(COLFMT) << right << "Value" << endl;
  for (int i = 1; i <= numbers; i++)
    cout << setw(COLFMT) << right << i
      << setw(COLFMT) << right << rand() << endl;

  // Loop to create random numbers after randomizing 
  // generator
  cout << "\nRandom-number generation AFTER "
    << "randomizing generator" << endl;
  srand(time(NULL));
  cout << setw(COLFMT) << right << "Index"
    << setw(COLFMT) << right << "Value" << endl;
  for (int i = 1; i <= numbers; i++)
    cout << setw(COLFMT) << right << i
    << setw(COLFMT) << right << rand() << endl;

  // Prompt user for and get number of random numbers
  cout << "\nRandom numbers in a user-specified range" 
    << endl;

  // Prompt user for and get range of random numbers
  cout << "Enter the bottom of the range: ";
  cin >> min;
  cout << "Enter the top of the range: ";
  cin >> max;
  cout << "Enter number of randoms to generate: ";
  cin >> numbers;

  // Loop to create random numbers
  cout << setw(COLFMT) << right << "Index"
    << setw(COLFMT) << right << "Value" << endl;
  for (int i = 1; i <= numbers; i++)
    cout << setw(COLFMT) << right << i
      << setw(COLFMT) << right << 
      ((rand() % (max - min + 1)) + min) << endl;

  // Show application close
  cout << "\nEnd of rand Function" << endl;

}

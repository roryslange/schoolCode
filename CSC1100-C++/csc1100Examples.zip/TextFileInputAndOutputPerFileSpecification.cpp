//==========================================================
//
// Title: Text file input and output per file specification
// Description:
//   This C++ console application demonstrates text file 
// reading and writing per file specification:
//
//   Field   Type    Start   End    Constant
//   State   string      1    16  COLFMT1
//   Year    integer    17    20  COLFMT2
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT1 = 16;
  const int COLFMT2 = 4;

  // Declare variables
  ifstream inFile;
  ofstream outFile;
  int lineCountIn;
  int lineCountOut;
  string line;
  string state;
  int year;

  // Declare constants
  const string INPUT_FILE_NAME = "USStatesInPerSpec.txt";
  const string OUTPUT_FILE_NAME = "USStatesOutPerSpec.txt";

  // Show application header
  cout << "Welcome to Text File Input and Output Per "
       << "Specification" << endl;
  cout << "------------------------------------------"
       << "-------------" << endl << endl;

  // Attempt to open input file
  inFile.open(INPUT_FILE_NAME);
  if (!inFile.is_open())
    cout << "Error: unable to open file '" 
      << INPUT_FILE_NAME << "'." << endl << endl;
  else 
  {

    // Attempt to open output file
    outFile.open(OUTPUT_FILE_NAME);
    if (!outFile.is_open())
      cout << "Error: unable to open file '"
      << OUTPUT_FILE_NAME << "'." << endl << endl;
    else
    {

      // Loop to read from input file and 
      // write to output file
      cout << "Reading lines from file '" 
        << INPUT_FILE_NAME
        << "'\nand writing lines to file '" 
        << OUTPUT_FILE_NAME
        << "' ..." << endl << endl;
      lineCountIn = 0;
      lineCountOut = 0;
      cout << "123456789012345678901234567890" << endl;
      while (inFile.good())
      {

        // Read and echo input file
        getline(inFile, line);
        cout << line << endl;

        // Parse line into variables
        // Function substr has two inputs:
        //   starting character, number of characters
        state = line.substr(0, COLFMT1);
        year = stoi(line.substr(COLFMT1, COLFMT2));
        lineCountIn = lineCountIn + 1;

        // Write to output file
        outFile << setw(COLFMT1) << left << state;
        outFile << setw(COLFMT2) << right << year << endl;
        lineCountOut = lineCountOut + 1;

      }
      cout << "123456789012345678901234567890" << endl;

      // Close input file
      inFile.close();
      cout << endl << lineCountIn 
        << " line(s) read from file '"
        << INPUT_FILE_NAME << "'." << endl;

      // Close output file
      outFile.close();
      cout << lineCountOut << " line(s) written to file '"
        << OUTPUT_FILE_NAME << "'." << endl << endl;

    }


  }

  // Show application close
  cout << "End of Text File Input and Output Per "
    << "Specification" << endl;

}

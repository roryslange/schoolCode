﻿//==========================================================
//
// Title: for Statements
// Description:
//   This C++ console application demonstrates for 
// statements.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT1 = 5;
  const int COLFMT2 = 10;
  const int COLFMT3 = 8;

  // Declare variables
  int n;
  string s;
  int spaces;

  // Show application header
  cout << "Welcome to for Statements" << endl;
  cout << "-------------------------" << endl;

  // Loop up from 1 to 5
  cout << "\nfor loop from 1 to 5" << endl;
  for (int i = 1; i <= 5; i++)
    cout << "i is now " << i << endl;

  // Loop up from 'a' to 'e'
  cout << "\nfor loop char from 'a' to 'e'" << endl;
  for (char c = 'a'; c <= 'e'; c++)
    cout << "c is now " << c << endl;

  // Loop up from 1.2 to 2.2
  cout << "\nfor loop with double from 1.2 to 2.2" << endl;
  cout << fixed << setprecision(8);
  float i = 0;
  cout << "Before the loop, i is " << i << endl;
  for (i = 1.2f; i <= 2.2f; i = i + .2f)
    cout << "i is now " << i << endl;
  cout << "After the loop, i is " << i << endl;

  // Loop down from 10 to 1 by 2
  cout << "\nfor loop from 10 to 1 by 2" << endl;
  for (int j = 10; j >= 2; j = j - 2)
    cout << "j is now " << j << endl;

  // Loop up from 10 to given number
  cout << "\nfor loop from 10 to given number" << endl;
  cout << "Enter a whole number to loop from 10 to: ";
  cin >> n;
  for (int k = 10; k <= n; k++)
    cout << "k is now " << k << endl;
  cout << "Looped from 10 to " << n << "." << endl;

  // Loop through each character in a string
  cout << "\nfor loop to show each string character" 
    << endl;
  cout << "Enter a string (spaces are okay): ";
  cin.ignore(100, '\n');  
    // Needed to scan past ENTER character in input buffer
  getline(cin, s);
  cout << setw(COLFMT1) << right << "Index"
    << setw(COLFMT2) << right << "Character" 
    << setw(COLFMT3) << right << "Code" << endl;
  for (int m = 0; m < s.length(); m++)
    cout << setw(COLFMT1) << right << m
      << setw(COLFMT2) << right << s.at(m)
      << setw(COLFMT3) << right << (int) (s.at(m)) << endl;

  // Loop with continue statement to count spaces
  cout << "\nfor loop to count spaces in string" << endl;
  spaces = 0;
  for (int i = 0; i < s.length(); i++)
  {
    if (s.at(i) != ' ')
      continue;  // Don't do this!!
    spaces = spaces + 1;
  }
  cout << "String: '" << s << "'" << endl;
  cout << "Length: " << s.length() << endl;
  cout << "Spaces: " << spaces << endl;

  // Adam exception: continue statement to skip divide by
  // zero
  cout << "\nfor loop to skip divide by zero" << endl;
  cout << fixed << setprecision(3);
  int mirror = 3;
  for (int a = -mirror; a <= mirror; a++)
  {
    if (a == 0)
      continue;
    cout << setw(COLFMT3) << right << a
      << setw(COLFMT3) << right << (4. / a) << endl;
  }

  // Superstition exception: continue statement to skip
  // Floor 13
  cout << "\nfor loop to skip Floor 13" << endl;
  for (int f = 1; f <= 17; f++)
  {
    if (f == 13)
      continue;
    cout << "Elevator is now on floor " << f << endl;
  }

  // Show application close
  cout << "\nEnd of for Statements" << endl;


}

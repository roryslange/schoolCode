#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{
  string firstName; string lastName; cout << "Welcome to Read and Echo First and Last Name" << endl; cout << "--------------------------------------------" << endl << endl; cout << "Enter the first name (no spaces): "; cin >> firstName; cout << "Enter the last name (no spaces): "; cin >> lastName; cout << "\nFull name: " << firstName << " " << lastName << endl; cout << "\nEnd of Read and Echo First and Last Name" << endl;
}

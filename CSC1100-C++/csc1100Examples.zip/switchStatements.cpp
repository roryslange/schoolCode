//==========================================================
//
// Title: switch Statements
// Description:
//   This C++ console application demonstrates switch 
// statements.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  char type;
  char oper;
  int iNum1;
  int iNum2;
  int SKU;
  int option;
  string applicance;

  // Show application header
  cout << "Welcome to switch Statements" << endl;
  cout << "----------------------------" << endl << endl;

  // Test which gas type entered
  cout << "If statement" << endl;
  cout 
    << "Enter a gas type (r-regular, m-mid-grade, p-premium): ";
  cin >> type;
  if (type == 'r')
    cout 
      << "Gas type 'regular' has an octane rating of 87."
      << endl;
  else if (type == 'm')
    cout 
      << "Gas type 'mid-grade' has an octane rating of 89."
      << endl;
  else if (type == 'p')
    cout 
      << "Gas type 'premium' has an octane rating of 92."
      << endl;
  else
    cout << "'" << type << "' is an unknown gas type."
      << endl;

  // Test which gas type entered
  cout << "\nSwitch statement 1 with char expression" 
    << endl;
  cout << "Using previously entered gas type of '" << type 
    << "'." << endl;
  switch (type)
  {
    case 'r':
      cout 
        << "Gas type 'regular' has an octane rating of 87."
        << endl;
      break;
    case 'm':
      cout 
        << "Gas type 'mid-grade' has an octane rating of 89."
        << endl;
      break;
    case 'p':
      cout 
        << "Gas type 'premium' has an octane rating of 92."
        << endl;
      break;
    default:
      cout << "'" << type << "' is an unknown gas type."
        << endl;
  }

  // Test which arithmetic operator entered
  cout << "\nSwitch statement 2 with char expression" 
    << endl;
  cout << "Enter first number: ";
  cin >> iNum1;
  cout << "Enter operator (*, /, or %): ";
  cin >> oper;
  cout << "Enter second number: ";
  cin >> iNum2;
  switch (oper)
  {
  case '*':
    cout << iNum1 << " * " << iNum2 << " = " 
         << (iNum1 * iNum2) << endl;
    break;
  case '/':
    cout << iNum1 << " / " << iNum2 << " = "
      << (iNum1 / iNum2) << endl;
    break;
  case '%':
    cout << iNum1 << " % " << iNum2 << " = "
      << (iNum1 % iNum2) << endl;
    break;
  default:
    cout << "Error: cannot handle operator '" << oper 
      << "'." << endl;
  }

  // Test which option entered
  cout << "\nSwitch statement 3 with int expression" 
    << endl;
  cout << "Enter an option (1 or 2): ";
  cin >> option;
  switch (option)
  {
    case 1:
      cout << "You selected option 1." << endl;
      break;
    case 2:
      cout << "You selected option 2." << endl;
      break;
    default:
      cout << "Error: option '" << option 
        << "' is invalid." << endl;
      break;
  }

  // Test which SKU entered
  cout << "\nSwitch statement 4 with int expression" 
    << endl;
  cout << "Enter a SKU: ";
  cin >> SKU;

  // Test SKU number and show product price and name
  cout << "The price and product of SKU '" << SKU 
    << "' is:" << endl;
  switch (SKU)
  {
    case 1597:
      cout 
        << "$249.99, Fitbit - Surge Large - Size Fitness " 
        << "Watch with Heart Rate Monitor - Black" << endl;
      break;
    case 1524:
      cout 
        << "$218.99, Fitbit - Surge Small - Size Fitness "
        << "Watch with Heart Rate Monitor - Black" << endl;
      break;
    case 1012:
      cout 
        << "$159.99, Microsoft - Band Smartwatch(Large) " 
        << "- Black" << endl;
      break;
    case 3029:
      cout 
        << "$152.99, Microsoft - Band Smartwatch(Medium) " 
        << "- Black" << endl;
      break;
    case 9307:
      cout 
        << "$54.99, Polar - FT4 Women's Heart Rate Monitor " 
        << "- Purple/Pink" << endl;
      break;
    case 5038:
      cout 
        << "$299.99, Garmin - Forerunner 225 Sport Watch " 
        << "- Black / Red" << endl;
      break;
    case 7081:
      cout 
        << "$167.99, Polar - M400 GPS Watch with Heart Rate " 
        << "Monitor - Black" << endl;
      break;
    default:
      cout << "Error: unknown SKU of '" << SKU << "'." 
        << endl;

  }

  // Test which option entered
  cout << "\nSwitch statement with bool expression" << endl;
  bool flag = true;
  switch (flag)
  {
  case 0:
    cout << "Flag is false." << endl;
    break;
  case 1:
    cout << "flag is true." << endl;
    break;
  }

  // Show application close
  cout << "\nEnd of switch Statements" << endl;

}

//==========================================================
//
// Title: String and Character Functions
// Description:
//   This C++ console application shows some string and 
// character functions.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// concatenatedStrings
//==========================================================
string concatenatedStrings(string s)
{
  return s;
}

//==========================================================
// concatenatedStrings
//==========================================================
string concatenatedStrings(string s1, string s2)
{
  return s1 + " " + s2;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare constants
  const int COLFMT1 = 24;
  const int COLFMT2 = 16;
  const int COLFMT3 = 8;

  // Declare variables
  string s1;
  string s2;
  string s3;
  string s;
  int i;
  string firstName;
  string lastName;
  string name;

  // Show application header
  cout << "Welcome to String and Character Functions" 
    << endl;
  cout << "-----------------------------------------" 
    << endl << endl;

  // Prompt for and get string 1
  cout << "Enter string 1 (no spaces): ";
  cin >> s1;

  // Prompt for and get string 2
  cout << "Enter string 2 (no spaces): ";
  cin >> s2;

  // Show column headers
  cout << endl;
  cout << setw(COLFMT1) << left << "Index"
    << setw(COLFMT2) << left << "Character" << endl;

  // Loop to show string 1 using subscript operator
  cout << "String 1: " << s1 << endl;
  for(int i = 0; i < s1.length(); i++)
    cout << setw(COLFMT1) << left << i
      << setw(COLFMT2) << left << s1[i] << endl;

  // Loop to show string 2 using function at
  cout << "String 2: " << s2 << endl;
  for (int i = 0; i < s2.length(); i++)
    cout << setw(COLFMT1) << left << i
      << setw(COLFMT2) << left << s2.at(i) << endl;

  // A run-time error is generated if [] or .at() specify
  // a number >= length of the string variable
  //cout << "Probable run-time error here: " 
  //  << s1.at(1000) << endl;

  // Concatenate strings
  cout << "\nString concatenation (s1 and s2)" << endl;

  s3 = s1 + " " + s2;
  cout << "Assignment statement 1: " << s3 << endl;

  s3 = "Hello " + s1;
  cout << "Assignment statement 2: " << s3 << endl;

  //s3 = "Hello " + "World!";  
    // Cannot concatenate two character arrays

  //s3 = s1 + 7;  
    // Cannot concatenate a string variable with an integer

  cout << "Concatenate strings call (one argument): "
    << concatenatedStrings(s1 + " " + s2) << endl;

  cout << "Concatenate strings call (two arguments): "
    << concatenatedStrings(s1, s2) << endl;

  // Show column headers
  cout << endl;
  cout << setw(COLFMT1) << left 
    << "Function/property"
    << setw(COLFMT2) << left << "String 1"
    << setw(COLFMT2) << left << "String 2" << endl;
  cout << setw(COLFMT1) << left << "String"
    << setw(COLFMT2) << left << s1
    << setw(COLFMT2) << left << s2 << endl;

  // Show some string functions
  cout << setw(COLFMT1) << left << "length"
    << setw(COLFMT2) << left << s1.length()
    << setw(COLFMT2) << left << s2.length() << endl;

  cout << setw(COLFMT1) << left << "substr(2, 3)"
    << setw(COLFMT2) << left << s1.substr(2, 3)
    << setw(COLFMT2) << left << s2.substr(2, 3) << endl;

  cout << setw(COLFMT1) << left << "find('e')"
    << setw(COLFMT2) << left << s1.find("e")
    << setw(COLFMT2) << left << s2.find("e") << endl;

  cout << setw(COLFMT1) << left << "rfind('e')"
    << setw(COLFMT2) << left << s1.rfind('e')
    << setw(COLFMT2) << left << s2.rfind("e") << endl;

  cout << "max_size() - maximum string size:  " 
    << s1.max_size() << endl;

  cout << "npos - no-match value:             "
    << s1.npos << endl;

  cout << "s2.append(s1) - s1 appended to s2: " 
    << s2.append(s1) << endl;

  // Attempt to convert string to integer
  cout << "\nConversion from string to integer" << endl;
  try
  {

    // Prompt for and get number
    cout << "Enter an integer: ";
    cin >> s;

    // Attempt to convert string to number
    i = stoi(s);
    cout << "'" << s << "' is a valid integer."
      << endl;

  }
  catch (const invalid_argument& ia)
  {
    cout << "Error: '" << s
      << "' is an invalid integer." << endl;
  }

  // Loop to show and test each character
  cout << "\nCharacter functions" << endl;
  cout << "String 1: " << s1 << endl;
  cout << setw(COLFMT3) << left << "Char"
    << setw(COLFMT3) << left << "Upper"
    << setw(COLFMT3) << left << "Lower"
    << setw(COLFMT3) << left << "Digit?"
    << setw(COLFMT3) << left << "Letter?"
    << setw(COLFMT3) << left << "AlphNum?"
    << setw(COLFMT3) << left << "Lower?"
    << setw(COLFMT3) << left << "Upper?"
    << setw(COLFMT3) << left << "Punct?" << endl;
  for (i = 0; i < s1.length(); i = i + 1)
  {
    cout << setw(COLFMT3) << left << s1[i]
      << setw(COLFMT3) << left << (char) toupper(s1[i])
      << setw(COLFMT3) << left << (char) tolower(s1[i])
      << setw(COLFMT3) << left << 
      (isdigit(s1[i]) ? "yes" : "no")
      << setw(COLFMT3) << left << 
      (isalpha(s1[i]) ? "yes" : "no")
      << setw(COLFMT3) << left << 
      (isalnum(s1[i]) ? "yes" : "no")
      << setw(COLFMT3) << left << 
      (islower(s1[i]) ? "yes" : "no")
      << setw(COLFMT3) << left << 
      (isupper(s1[i]) ? "yes" : "no")
      << setw(COLFMT3) << left << 
      (ispunct(s1[i]) ? "yes" : "no") << endl;
  }

  // Show application close
  cout << "\nEnd of String and Character Functions" << endl;

}

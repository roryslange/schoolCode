//==========================================================
//
// Title: Rectangle Perimeter and Area Calculator, v2
// Description:
//   This C++ console application calculates the perimeter 
// and area of a rectangle.  It prompts for and gets from 
// the user the length and width of the rectangle, and 
// calculates and prints the area and perimeter.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// calculateAreaUsingValueMethod
//==========================================================
double calculateAreaUsingValueMethod(double ln, double wd)
{
  return ln * wd;
}

//==========================================================
// calculatePerimeterUsingValueMethod
//==========================================================
double calculatePerimeterUsingValueMethod(double ln, 
  double wd)
{
  return 2 * (ln + wd);
}

//==========================================================
// showResults
//==========================================================
void showResults(double ln, double wd, double pr, double ar)
{
  cout << "\nLength:    " << ln << " meters" << endl;
  cout << "Width:     " << wd << " meters" << endl;
  cout << "Perimeter: " << pr << " meters" << endl;
  cout << "Area:      " << ar << " square meters" << endl;
}

//==========================================================
// calculateAreaUsingVoidMethod
//==========================================================
void calculateAreaUsingVoidMethod(double ln, double wd)
{

  // Declare variables
  double pr;
  double ar;

  // Calculate perimeter and area
  pr = calculatePerimeterUsingValueMethod(ln, wd);
  ar = calculateAreaUsingValueMethod(ln, wd);

  // Show inputs and outputs
  showResults(ln, wd, pr, ar);

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  double length;
  double width;
  double perimeter;
  double area;

  // Show application header
  cout << "Welcome to Rectangle Perimeter and Area " 
    << "Calculator, v2" << endl;
  cout << "----------------------------------------"
    << "--------------" << endl << endl;

  // Prompt for and get length
  cout << "Enter the length (meters, between 0 and 100): ";
  cin >> length;
  while (length < 0 || length > 100)
  {
    cout << "Error: invalid length of " << length << "." 
      << endl;
    cout << "Enter the length (meters, between 0 and 100): ";
    cin >> length;
  }

  // Prompt for and get width
  cout << "Enter the width (meters, between 0 and 100): ";
  cin >> width;
  while (width < 0 || width > 100)
  {
    cout << "Error: invalid width of " << width  << "." 
      << endl;
    cout << "Enter the width (meters, between 0 and 100): ";
    cin >> width;
  }

  // Calculate and show using void method
  cout << "\nCalculate and show using void method";
  calculateAreaUsingVoidMethod(length, width);

  // Calculate and show using value methods
  cout << "\nCalculate and show using value methods";
  perimeter = 
    calculatePerimeterUsingValueMethod(length, width);
  area = calculateAreaUsingValueMethod(length, width);
  showResults(length, width, perimeter, area);

  // Show application close
  cout << "\nEnd of Rectangle Perimeter and Area "
    "Calculator, v2" << endl;

}

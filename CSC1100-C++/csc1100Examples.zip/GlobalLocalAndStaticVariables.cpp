//==========================================================
//
// Title: Global, local, and static Variables
// Description:
//   This C++ console application demonstrates global and 
// local variables.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global constants and variables
//==========================================================

// Declare constants
const int COLFMT1 = 40;
const int COLFMT2 = 10;

// Declare variables
int g_num;
int sameAsLocal;

//==========================================================
// changeValues
//==========================================================
void changeValues(int p_num)
{

  // Show values before change
  cout << setw(COLFMT1) << left
    << "In changeValues call - before changes"
    << setw(COLFMT2) << left << g_num
    << setw(COLFMT2) << left << p_num << endl;

  // Change values
  g_num = 87;
  p_num = 9;

  // Show values after change
  cout << setw(COLFMT1) << left
    << "In changeValues call - after changes"
    << setw(COLFMT2) << left << g_num
    << setw(COLFMT2) << left << p_num << endl;

}

//==========================================================
// accessVariablesWithSameNames
//==========================================================
void accessVariablesWithSameNames()
{

  // Declare local variables
  int sameAsLocal = 4;  
    // Local variable with same name as global variable

  // Show column headers
  cout << setw(COLFMT1) << left << "" 
    << setw(COLFMT2) << left << "Global" 
    << setw(COLFMT2) << left << "Local" << endl;

  // Set global variable (using scope resolution operator)
  ::sameAsLocal = 63;

  // Show values
  cout << setw(COLFMT1) << left 
    << "Variables with same names" 
    << setw(COLFMT2) << left << ::sameAsLocal 
    << setw(COLFMT2) << left << sameAsLocal << endl;

}

//==========================================================
// changeStaticValues
//==========================================================
void changeStaticValues()
{

  // Declare variables
  static int st_num = 72;

  // Show values before change
  cout << setw(COLFMT1) << left
    << "In changeStaticValues - before change"
    << setw(COLFMT2) << left << st_num << endl;

  // Change values
  st_num = st_num + 1;

  // Show values after change
  cout << setw(COLFMT1) << left
    << "In changeStaticValues - after change"
    << setw(COLFMT2) << left << st_num << endl;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare local variables
  int l_num;
  
  // Show application header
  cout << "Welcome to Global, local, and static Variables" 
    << endl;
  cout << "----------------------------------------------" 
    << endl << endl;

  // Show column headers
  cout << setw(COLFMT1) << left << ""
    << setw(COLFMT2) << left << "Global"
    << setw(COLFMT2) << left << "Local"
    << setw(COLFMT2) << left << "Static" << endl;

  // Set global and local variables
  g_num = 55;
  l_num = 4;

  // Show values before change
  cout << setw(COLFMT1) << left
    << "In main - before changeValues call"
    << setw(COLFMT2) << left << g_num
    << setw(COLFMT2) << left << l_num << endl;

  // Change values
  changeValues(l_num);

  // Show values after change
  cout << setw(COLFMT1) << left
    << "In main - after changeValues call"
    << setw(COLFMT2) << left << g_num
    << setw(COLFMT2) << left << l_num << endl;

  cout << "\nAny changes to global variables are "
    << "kept after a method call." << endl;
  cout << "Any changes to local variables are NOT "
    << "kept after a method call." << endl << endl;

  // Access variables With same names
  accessVariablesWithSameNames();

  // Access static variable
  cout << endl;
  cout << setw(COLFMT1) << left << ""
    << setw(COLFMT2) << left << "Static" << endl;
  changeStaticValues();
  changeStaticValues();

  // Show application close
  cout << "\nEnd of Global, local, and static Variables" 
    << endl;

}

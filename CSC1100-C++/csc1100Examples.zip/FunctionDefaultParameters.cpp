//==========================================================
//
// Title: Function Default Parameters
// Description:
//   This C++ console application demonstrates function 
// default parameters.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global variables
//==========================================================
const int COL_WIDTH = 12;

//==========================================================
// funWithParms
// Because of its default parameters, this function has 
// three signatures:
//   funWithParms(string, int)
//   funWithParms(string, int, int)
//   funWithParms(string, int, int, int)
//==========================================================
void funWithParms(string heading, int p1, int p2 = 200, 
  int p3 = 3000)
{
  cout << setw(COL_WIDTH) << left << heading
    << setw(COL_WIDTH) << right << p1
    << setw(COL_WIDTH) << right << p2
    << setw(COL_WIDTH) << right << p3 << endl;
}

////==========================================================
//// funWithParms
//// This function cannot be declared because the above 
//// function is already using this signature.  This is an 
//// ambiguous function signature.
////==========================================================
//void funWithParms(int p1, string heading)
//{
//  cout << setw(COL_WIDTH) << left << heading
//    << setw(COL_WIDTH) << right << p1 << endl;
//}

//==========================================================
// main
//==========================================================
int main()
{

  // Show application header
  cout << "Welcome to Function Default Parameters" << endl;
  cout << "--------------------------------------" << endl 
    << endl;

  // Print headings
  cout << setw(COL_WIDTH) << left << "Call" 
    << setw(COL_WIDTH) << right << "p1" 
    << setw(COL_WIDTH) << right << "p2"
    << setw(COL_WIDTH) << right << "p3" << endl;

  // Loop to process menu options
  funWithParms("No defaults", 11, 22, 33);
  funWithParms("One default", 44, 55);
  funWithParms("Two defaults", 66);

  // Show application close
  cout << "\nEnd of Function Default Parameters" << endl;

}

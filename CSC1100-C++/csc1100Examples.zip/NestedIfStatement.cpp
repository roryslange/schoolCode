//==========================================================
//
//  Title: Nested if Statements
//  Description:
//    This C++ console application demonstrates nested if 
// statements.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  string make;
  string model;

  // Show application header
  cout << "Welcome to Nested if Statements" << endl;
  cout << "-------------------------------" << endl << endl;

  // Prompt for and get car make
  cout << "Enter a car make: ";
  cin >> make;

  // Test car make
  if (make == "Ford")
  {

    // Prompt for and get car model
    cout 
      << "Enter a car model (o-Focus, u-fusion, t-Taurus): ";
    cin >> model;

    // Test car model
    cout << endl;
    if (model == "o")
      cout << "You have a Ford compact car." << endl;
    else if (model == "u")
      cout << "You have a Ford mid-size car." << endl;
    else if (model == "t")
      cout << "You have a Ford full-size car." << endl;
    else
      cout << "We're not sure what type of Ford model '" 
        << model << "' is." << endl;

  }
  else if (make == "GM")
  {

    // Prompt for and get car model
    cout 
      << "Enter a car model (z-Cruze, m-Malibu, r-Regal): ";
    cin >> model;

    // Test car model
    cout << endl;
    if (model == "z")
      cout << "You have a GM compact car." << endl;
    else if (model == "m")
      cout << "You have a GM mid-size car." << endl;
    else if (model == "r")
      cout << "You have a GM full-size car." << endl;
    else
      cout << "We're not sure what type of GM model '" 
        << model << "' is." << endl;

  }
  else
    cout 
      << "This app is in beta - we can't handle car make '" 
      << make << "' yet!" << endl;

  // Show application close
  cout << "\nEnd of Nested if Statements" << endl;

}

//==========================================================
//
// Title: Reference and Pointer Variables
// Description:
//   This C++ console application demonstrates reference and
// pointer variables and operators:
//   & Address operator
//     -Means "the address of".
//     -Is followed by a variable.
//   * Indirection operator
//     -Means "the value at".
//     -Is followed by a pointer variable.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int COLFMT = 14;

//==========================================================
// main
//==========================================================
int main()
{

  // Declare scalar variables
  int iNum = 78;
  double rNum = 3.97;
  string str = "WSU";
  bool flag = false;

  // Declare reference variables
  int &iRef = iNum;
  double &rRef = rNum;
  string &sRef = str;
  bool &bRef = flag;

  // Declare pointer variables
  int *iPtr = &iNum;
  double *rPtr = &rNum;
  string *strPtr = &str;
  bool *flagPtr = &flag;

  // Show application header
  cout << "Welcome to Reference and Pointer Variables" 
    << endl;
  cout << "------------------------------------------" 
    << endl << endl;

  // Show integer variable information
  cout << "Variable iNum before change (iNum and iRef " 
    << "refer to same variable)" << endl;
  cout << setw(COLFMT) << left << "iNum:"
    << setw(COLFMT) << right << iNum << endl;
  cout << setw(COLFMT) << left << "iRef:"
    << setw(COLFMT) << right << iRef << endl << endl;

  // Change and reshow integer variable information
  iNum = iNum + 10;
  cout << "Variable iNum after 'iNum = iNum + 10;'" 
    << endl;
  cout << setw(COLFMT) << left << "iNum:"
    << setw(COLFMT) << right << iNum << endl;
  cout << setw(COLFMT) << left << "iRef:"
    << setw(COLFMT) << right << iRef << endl << endl;

  // Change and reshow integer variable information
  iRef = iRef + 10;
  cout << "Variable iNum after 'iRef = iRef + 10;'" 
    << endl;
  cout << setw(COLFMT) << left << "iNum:"
    << setw(COLFMT) << right << iNum << endl;
  cout << setw(COLFMT) << left << "iRef:"
    << setw(COLFMT) << right << iRef << endl << endl;

  // Show column headers
  cout << setw(COLFMT) << left << "Variable" 
    << setw(COLFMT) << right << "Var value" 
    << setw(COLFMT) << right << "Value at ptr"
    << setw(COLFMT) << right << "Addr of var"
    << setw(COLFMT) << right << "Ptr value" << endl;

  // Show integer variable information
  cout << setw(COLFMT) << left << "iNum"
    << setw(COLFMT) << right << iNum 
    << setw(COLFMT) << right << *iPtr
    << setw(COLFMT) << right << &iNum
    << setw(COLFMT) << right << iPtr << endl;

  // Show double variable information
  cout << setw(COLFMT) << left << "rNum"
    << setw(COLFMT) << right << rNum
    << setw(COLFMT) << right << *rPtr
    << setw(COLFMT) << right << &rNum
    << setw(COLFMT) << right << rPtr << endl;

  // Show string variable information
  cout << setw(COLFMT) << left << "str"
    << setw(COLFMT) << right << str
    << setw(COLFMT) << right << *strPtr
    << setw(COLFMT) << right << &str
    << setw(COLFMT) << right << strPtr << endl;

  // Show boolean variable information
  cout << setw(COLFMT) << left << "flag"
    << setw(COLFMT) << right << flag
    << setw(COLFMT) << right << *flagPtr
    << setw(COLFMT) << right << &flag
    << setw(COLFMT) << right << flagPtr << endl;

  // Show pointer address information
  cout << "\nPointer addresses" << endl;
  cout << setw(COLFMT) << left << "iPtr"
    << setw(COLFMT) << right << &iPtr << endl;
  cout << setw(COLFMT) << left << "rPtr"
    << setw(COLFMT) << right << &rPtr << endl;
  cout << setw(COLFMT) << left << "strPtr"
    << setw(COLFMT) << right << &strPtr << endl;
  cout << setw(COLFMT) << left << "flagPtr"
    << setw(COLFMT) << right << &flagPtr << endl;

  // Show application close
  cout << "\nEnd of Reference and Pointer Variables" 
    << endl;

}

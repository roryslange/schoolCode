//==========================================================
//
// Title: Data Types
// Description:
//   This C++ console application lists integer, real, and 
// other data types and their sizes, minimums, and maximums.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT1 = 18;
  const int COLFMT2 = 21;
  const int COLFMT3 = 30;
  const int COLFMT4 = 6;

  // Declare variables
  string s = "Hello All!";

  // Show application header
  cout << "Welcome to Data Types" << endl;
  cout << "---------------------" << endl << endl;
  
  // Show integer data types
  cout << setw(COLFMT1) << left << "Integer Data Types" 
    << setw(COLFMT2) << right << "Min" 
    << setw(COLFMT3) << right << "Max" 
    << setw(COLFMT4) << right << "Bytes" << endl;

  cout << setw(COLFMT1) << left << "char" 
    << setw(COLFMT2) << right << CHAR_MIN 
    << setw(COLFMT3) << right << CHAR_MAX 
    << setw(COLFMT4) << right << sizeof(char) << endl;
  cout << setw(COLFMT1) << left << "unsigned char"
    << setw(COLFMT2) << right << 0
    << setw(COLFMT3) << right << UCHAR_MAX
    << setw(COLFMT4) << right << sizeof(char) << endl;

  cout << setw(COLFMT1) << left << "short"
    << setw(COLFMT2) << right << SHRT_MIN 
    << setw(COLFMT3) << right << SHRT_MAX 
    << setw(COLFMT4) << right << sizeof(short) << endl;
  cout << setw(COLFMT1) << left << "unsigned short"
    << setw(COLFMT2) << right << 0
    << setw(COLFMT3) << right << USHRT_MAX
    << setw(COLFMT4) << right << sizeof(short) << endl;

  cout << setw(COLFMT1) << left << "int" 
    << setw(COLFMT2) << right << INT_MIN 
    << setw(COLFMT3) << right << INT_MAX 
    << setw(COLFMT4) << right << sizeof(int) << endl;
  cout << setw(COLFMT1) << left << "unsigned int"
    << setw(COLFMT2) << right << 0
    << setw(COLFMT3) << right << UINT_MAX
    << setw(COLFMT4) << right << sizeof(int) << endl;

  cout << setw(COLFMT1) << left << "long" 
    << setw(COLFMT2) << right << LONG_MIN 
    << setw(COLFMT3) << right << LONG_MAX 
    << setw(COLFMT4) << right << sizeof(long) << endl;
  cout << setw(COLFMT1) << left << "unsigned long"
    << setw(COLFMT2) << right << 0
    << setw(COLFMT3) << right << ULONG_MAX
    << setw(COLFMT4) << right << sizeof(long) << endl;

  cout << setw(COLFMT1) << left << "long long" 
    << setw(COLFMT2) << right << LLONG_MIN 
    << setw(COLFMT3) << right << LLONG_MAX 
    << setw(COLFMT4) << right << sizeof(long) * 2 << endl;
  cout << setw(COLFMT1) << left << "unsigned long long"
    << setw(COLFMT2) << right << 0
    << setw(COLFMT3) << right << ULLONG_MAX
    << setw(COLFMT4) << right << sizeof(long)* 2 << endl;

  // Show real-number data types
  cout << endl;
  cout << setw(COLFMT1) << left << "Real Data Types"
    << setw(COLFMT2) << right << "Min"
    << setw(COLFMT3) << right << "Max"
    << setw(COLFMT4) << right << "Bytes" << endl;

  cout << setw(COLFMT1) << left << "float"
    << setw(COLFMT2) << right << FLT_MIN
    << setw(COLFMT3) << right << FLT_MAX
    << setw(COLFMT4) << right << sizeof(float) << endl;

  cout << setw(COLFMT1) << left << "double"
    << setw(COLFMT2) << right << DBL_MIN
    << setw(COLFMT3) << right << DBL_MAX
    << setw(COLFMT4) << right << sizeof(double) << endl;

  cout << setw(COLFMT1) << left << "long double"
    << setw(COLFMT2) << right << LDBL_MIN
    << setw(COLFMT3) << right << LDBL_MAX
    << setw(COLFMT4) << right << sizeof(long double) << endl;

  // Show other data type
  cout << endl;
  cout << setw(COLFMT1) << left << "Other Data Types"
    << setw(COLFMT2) << right << "Min"
    << setw(COLFMT3) << right << "Max"
    << setw(COLFMT4) << right << "Bytes" << endl;

  cout << setw(COLFMT1) << left << "bool"
    << setw(COLFMT2) << right << "0"
    << setw(COLFMT3) << right << "1"
    << setw(COLFMT4) << right << sizeof(bool) << endl;

  cout << setw(COLFMT1) << left << "string"
    << setw(COLFMT2) << right << "0"
    << setw(COLFMT3) << right << s.max_size()
    << setw(COLFMT4) << right << sizeof(string) << endl;

  // Show application close
  cout << "\nEnd of Data Types" << endl;

}

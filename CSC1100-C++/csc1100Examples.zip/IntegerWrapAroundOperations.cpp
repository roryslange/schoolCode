//==========================================================
//
// Title: Integer Wrap-around Operations
// Description:
//   This C++ console application shows an integer overflow
// and a short underflow.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int i = INT_MAX - 2;
  short s = -SHRT_MAX + 1;

  // Show application header
  cout << "Welcome to Integer Wrap-around Operations" 
    << endl;
  cout << "=========================================" 
    << endl << endl;

  // Show int overflow
  cout << "int overflow for variable i" << endl;
  cout << "---------------------------------" << endl;
  cout << "i starting at " << i << endl;

  i = i + 1;
  cout << "\n1 added to i ..." << endl;
  cout << "i is now      " << i << endl;

  i = i + 1;
  cout << "\n1 added to i ..." << endl;
  cout << "i is now      " << i 
    << " <- max value for data type 'int'" << endl;

  i = i + 1;
  cout << "\n1 added to i ..." << endl;
  cout << "i is now      " << i 
    << " <- min value for data type 'int'" << endl;

  i = i + 1;
  cout << "\n1 added to i ..." << endl;
  cout << "i is now      " << i << endl;

  i = i + 1;
  cout << "\n1 added to i ..." << endl;
  cout << "i is now      " << i << endl;

  // Show short overflow
  cout << endl;
  cout << "short underflow for variable s" << endl;
  cout << "------------------------------" << endl;
  cout << "s starting at " << s << endl;

  s = s - 1;
  cout << "\n1 subtracted from s ..." << endl;
  cout << "s is now      " << s << endl;

  s = s - 1;
  cout << "\n1 subtracted from s ..." << endl;
  cout << "s is now      " << s 
    << " <- min value for data type 'short'" << endl;

  s = s - 1;
  cout << "\n1 subtracted from s ..." << endl;
  cout << "s is now      " << s 
    << " <- max value for data type 'short'" << endl;

  s = s - 1;
  cout << "\n1 subtracted from s ..." << endl;
  cout << "s is now      " << s << endl;

  s = s - 1;
  cout << "\n1 subtracted from s ..." << endl;
  cout << "s is now      " << s << endl;

  // Show application close
  cout << "\nEnd of Integer Wrap-around Operations" << endl;

}

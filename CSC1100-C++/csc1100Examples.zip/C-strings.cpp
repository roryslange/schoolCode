//==========================================================
//
// Title: cin Statements - C-strings
// Description:
//   This C++ console application shows C-strings.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int ARRAY_SIZE = 12;
const int COLFMT = 12;

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  char arr1[ARRAY_SIZE] = "Detroit";  // C-string
  char arr2[ARRAY_SIZE];  // C-string
  string str1;
  string str2 = "Michigan";

  // Show application header
  cout << "Welcome to C-strings" << endl;
  cout << "--------------------" << endl << endl;
  
  // Convert C-string (character array) to string
  cout << "C-string -> string conversion" << endl;
  str1 = arr1;
  cout << setw(COLFMT) << left << "Array:"
    << arr1 << endl;
  cout << setw(COLFMT) << left << "String:"
    << arr1 << endl;

  // Convert string to C-string (character array)
  cout << "\nString -> C-string conversion" << endl;
  strcpy_s(arr2, str2.c_str());
  cout << setw(COLFMT) << left << "String:"
    << str2 << endl;
  cout << setw(COLFMT) << left << "Array:"
    << arr2 << endl;

  // Show application close
  cout << "\nEnd of C-strings" 
    << endl;

}

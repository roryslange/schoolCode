//==========================================================
//
//  Title: while Statements
//  Description:
//    This C++ console application demonstrates while 
// statements.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// main
//==========================================================
int main()
{

  // Jason's constant
  const char DEGREE_SYMBOL = (char) 167;

  // Declare variables
  int i;
  int j;
  int k;
  int n;
  int year;
  double temperature;
  bool numBad;
  string numStr;
  int num;
  char letter;
  string city;
  int option;
  char vowel;
  
  // Show application header
  cout << "Welcome to while Statements" << endl;
  cout << "---------------------------" << endl << endl;

  //--------------------------------------------------------
  // Generic loops
  //--------------------------------------------------------

  // Loop up from 1 to 5
  cout << "while loop from 1 to 5" << endl;
  i = 1;
  while (i <= 5)
  {
    cout << "i is now " << i << endl;
    i = i + 1;
  }
  cout << "Looped up from 1 to 5." << endl;

  // Loop down from 7 to 4
  cout << "\nwhile loop from 7 to 4" << endl;
  j = 7;
  while (j > 3)
  {
    cout << "j is now " << j << endl;
    j = j - 1;
  }
  cout << "Looped down from 7 to 4." << endl;

  // Loop up from 10 to given number
  cout << "\nwhile loop from 10 to given number" << endl;
  k = 10;
  cout << "Enter a whole number to loop from 10 to: ";
  cin >> n;
  while (k <= n)
  {
    cout << "k is now " << k << endl;
    k = k + 1;
  }
  cout << "Looped from 10 to " << n << "." << endl;

  // Infinite loop - overflow
  cout << "\nInfinite loop that stops due to overflow" 
    << endl;
  i = INT_MAX;
  while (i >= 0)
  {
    cout << "i in the loop is now " << i << endl;
    i = i + 1;
  }
  cout << "i after the loop is " << i << endl;

  // Infinite loop - underflow
  cout << "\nInfinite loop that stops due to underflow" 
    << endl;
  i = -INT_MAX;
  while (i <= 0)
  {
    cout << "i in the loop is now " << i << endl;
    i = i - 1;
  }
  cout << "i after the loop is " << i << endl;

  //// Infinte loop - eventual underflow
  //cout << "\nInfinite loop that eventually stops due to "
  //  << "underflow" << endl;
  //i = 1;
  //while (i <= 5)
  //{
  //  cout << "i is now " << i << endl;
  //  i = i - 1;
  //}

  //// Infinte loop - used = instead of ==
  ////aka used assignment statement instead of condition
  ////condition (year = 2020) is actually an assignment 
  ////statement which evaluates to:
  ////  true if righthand side is nonzero.
  ////  false if righthand side is zero.
  //cout << "\nAssignment statement instead of condition"
  //  << endl;
  //cout << "Enter a year: ";
  //cin >> year;
  //while (year = 2020)
  //{
  //  cout << "You entered the year 2020!" << endl;
  //  cout << "Enter a year: ";
  //  cin >> year;
  //}

  //--------------------------------------------------------
  // Validation loops
  //--------------------------------------------------------

  // Validation loop: loop until valid year entered
  cout << "\nValidation loop 1" << endl;
  cout << "\nEnter a year (four digits) after 2010: ";
  cin >> year;
  while (year <= 2010 || year > 9999)  
    // Using Kayla's four-digit validation
  {
    cout << "Error: invalid year of " << year << "." << endl;
    cout << "\nEnter a year (four digits) after 2010: ";
    cin >> year;
  }
  cout << "'" << year << "' is a valid year." << endl;

  // Validation loop: loop until valid temperature entered
  cout << "\nValidation loop 2" << endl;
  cout << "\nEnter a temperature between 0 and 100 (" 
    << DEGREE_SYMBOL << "C): ";
  cin >> temperature;
  while (temperature < 0 || temperature > 100)
  {
    cout << "Error: temperature of " << temperature 
      << DEGREE_SYMBOL << "C is not between 0 and 100." 
      << endl;
    cout << "\nEnter a temperature between 0 and 100 (" 
      << DEGREE_SYMBOL << "C): ";
    cin >> temperature;
  }
  cout << "'" << temperature << DEGREE_SYMBOL 
    << "C' is a valid temperature." << endl;

  // Validation loop: loop until an upper case letter entered
  cout << "\nValidation loop 3" << endl;
  cout << "\nEnter an upper case letter (A-Z): ";
  cin >> letter;
  while (!isupper(letter))  // (letter < 'A' || letter > 'Z')
  {
    cout << "Error: '" << letter 
      << "' is not an upper case letter." << endl;
    cout << "\nEnter an upper case letter (A-Z): ";
    cin >> letter;
  }
  cout << "'" << letter << "' is an upper case letter." 
    << endl;

  // Validation loop: loop until valid whole number entered
  cout << "\nValidation loop 4" << endl;
  numBad = true;
  while (numBad)
  {

    // Prompt for and get number as string
    cout << "\nEnter a whole number: ";
    cin >> numStr;

    // Attempt to convert string to integer
    try
    {
      num = stoi(numStr);
      cout << "'" << num << "' is a valid whole number." 
        << endl;
      numBad = false;
    }
    catch (const invalid_argument& ia)
    {
      cout << "Error: '" << numStr 
        << "' is an invalid whole number." << endl;
    }
       
  }

  //--------------------------------------------------------
  // Sentinel loops
  //--------------------------------------------------------

  // Sentinel loop: loop until sentinel value -99 read
  cout << "\nSentinel loop 1" << endl;
  cout << "\nEnter a whole number (-99 to exit): ";
  cin >> num;
  while (num != -99)
  {

    // Test if number is even or odd
    if (num % 2 == 0)
      cout << "The number entered (" << num << ") is even." 
        << endl;
    else
      cout << "The number entered (" << num << ") is odd."
      << endl;

    // Get next number
    cout << "\nEnter a whole number (-99 to exit): ";
    cin >> num;

  }
  cout << "Sentinel value '" << num << "' entered." << endl;

  // Sentinel loop: loop until sentinel value 'x' read
  cout << "\nSentinel loop 2" << endl;
  cout << "\nEnter a city (x to exit): ";
  cin >> city;
  while (!(city.length() == 1 && tolower(city.at(0)) == 'x'))
  {
    cout << "The city you entered is '" << city << "'." 
      << endl;
    cout << "\nEnter a city (x to exit): ";
    cin >> city;
  }
  cout << "Sentinel value '" << city << "' entered." 
    << endl;

  // Menu/sentinel loop: loop until user exits menu
  cout << "\nSentinel loop 3" << endl;
  cout << "\nApplication Menu" << endl;
  cout << "1 - first option" << endl;
  cout << "2 - second option" << endl;
  cout << "3 - third option" << endl;
  cout << "9 - Exit" << endl;
  cout << "\nEnter an option: ";
  cin >> option;
  while (option != 9)
  {

    // Test which option selected
    switch (option)
    {
      case 1: 
        cout << "Doing first option here ..." << endl;
        break;
      case 2:
        cout << "Doing second option here ..." << endl;
        break;
      case 3:
        cout << "Doing third option here ..." << endl;
        break;
      default:
        cout << "Error: unknown option of " << option 
          << "." << endl;

    }

    // Show menu and prompt for and get option
    cout << "\nApplication Menu" << endl;
    cout << "1 - first option" << endl;
    cout << "2 - second option" << endl;
    cout << "3 - third option" << endl;
    cout << "9 - Exit" << endl;
    cout << "\nEnter an option: ";
    cin >> option;

  }
  cout << "Done processing menu options." << endl;

  // Kevin loop: loop until sentinel value (nonnumeric) read
  cout << "\nSentinel loop 4" << endl;

  // Attempt to convert strings to integers
  try
  {

    // Loop while user entered number
    while (true)
    {

      // Get next number
      cout << "\nEnter a whole number (letter to exit): ";
      cin >> numStr;

      // Attempt to convert number to string
      num = stoi(numStr);

      // Test if number is even or odd
      if (num % 2 == 0)
        cout << "The number entered (" << num << ") is even."
        << endl;
      else
        cout << "The number entered (" << num << ") is odd."
        << endl;

    }

  }
  catch (const invalid_argument& ia)
  {
    cout << "Sentinel value '" << numStr << "' entered."
      << endl;
  }

  //--------------------------------------------------------
  // Combined sentinel-validation loops
  //--------------------------------------------------------

  // Combined sentinel-validation loop: loop until sentinel value read
  cout << "\nCombined sentinel-validation loop" << endl;
  cout << "\nEnter a vowel (x to exit): ";
  cin >> vowel;
  vowel = tolower(vowel);
  while (vowel != 'x')
  {

    // Test if character is not a vowel
    if (vowel != 'a' && vowel != 'e' && vowel != 'i' &&
      vowel != 'o' && vowel != 'u')
      cout << "Error: '" << vowel << "' is not a vowel." 
        << endl;
    else
      cout << "Yes, that's a vowel." << endl;

    cout << "\nEnter a vowel (x to exit): ";
    cin >> vowel;
    vowel = tolower(vowel);
  }
  cout << "Sentinel value '" << vowel << "' entered."
    << endl;

  // Show application close
  cout << "\nEnd of while Statements" << endl;

}

//==========================================================
//
// Title: structs
// Description:
//   This C++ console application demonstrates structs.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================

const int COLFMT = 24;

struct employee
{
  int ID;
  string firstName;
  string lastName;
  double hourlyRate = 20;
};

//==========================================================
// printEmployee
//==========================================================
void printEmployee(string variable, employee emp)
{
  cout << "\nEmployee information (ID " << emp.ID << ")" 
    << endl;
  cout << setw(COLFMT) << left << "Variable:"
    << setw(COLFMT) << left << variable << endl
    << setw(COLFMT) << left << "First name:"
    << setw(COLFMT) << left << emp.firstName << endl
    << setw(COLFMT) << left << "Last name:"
    << setw(COLFMT) << left << emp.lastName << endl
    << setw(COLFMT) << left << "Hourly rate ($):"
    << setw(COLFMT) << left << emp.hourlyRate << endl;
}

//==========================================================
// setEmployee
//==========================================================
employee setEmployee()
{

  // Declare variables
  employee emp;

  // Prompt for and get employee data
  cout << "\nEnter employee ID: ";
  cin >> emp.ID;
  cout << "Enter employee first name: ";
  cin >> emp.firstName;
  cout << "Enter employee last name: ";
  cin >> emp.lastName;
  cout << "Enter employee hourly rate: ";
  cin >> emp.hourlyRate;
  return emp;

}

//==========================================================
// compareEmployees
//==========================================================
void compareEmployees(employee emp1, employee emp2)
{
  cout << "\nComparing employees ..." << endl;
  if (emp1.ID == emp2.ID &&
      emp1.firstName == emp2.firstName &&
      emp1.lastName == emp2.lastName &&
      emp1.hourlyRate == emp2.hourlyRate)
    cout << "\emp1 and emp2 are the same." << endl;
  else
    cout << "\nemp1 and emp2 are NOT the same." << endl;
}

//==========================================================
// updateHourlyRate
//==========================================================
employee updateHourlyRate(employee emp)
{
  cout << "\nEnter new hourly rate for employee " 
    << emp.ID << ": ";
  cin >> emp.hourlyRate;
  return emp;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  employee emp1;
  employee emp2;

  // Show application header
  cout << "Welcome to structs" << endl;
  cout << "------------------" << endl;
  
  // Format financial numbers
  cout << fixed << setprecision(2);

  // Set employee from assigned values
  cout << "\nSetting employee information from "
    << "assignment statements ..." << endl;
  emp1.ID = 513;
  emp1.firstName = "Sam";
  emp1.lastName = "Stocker";
  printEmployee("emp1 - using default value for hourly rate.", emp1);
  emp1.hourlyRate = 14.75;
  printEmployee("emp1 - using assigned value for hourly rate.", emp1);
  // cout << "struct variable emp1: " << emp1 << endl;  
    // Cannot print struct variable using only its name

  //emp2 = emp1;

  // Set employee from read values
  cout
    << "\nSetting employee information from user ..."
    << endl;
  emp2 = setEmployee();
  printEmployee("emp2", emp2);

  // Compare employees
  compareEmployees(emp1, emp2);

  // Change hourly rate
  cout
    << "\nUpdating employee information from user ..."
    << endl;
  emp2 = updateHourlyRate(emp2);
  printEmployee("emp2", emp2);

  // Show application close
  cout << "\nEnd of structs" << endl;

}

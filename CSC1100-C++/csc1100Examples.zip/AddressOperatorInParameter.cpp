//==========================================================
//
// Title: Address operator in parameter
// Description:
//   This C++ console application demonstrates using the 
// address operator to enable multiple values to be returned 
// from a function.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int COLFM1 = 36;
const int COLFM2 = 8;

//==========================================================
// changesStay
//==========================================================
void changesStay(int width, int length)
{
  width = width + 1;
  length = length + 2;
}

//==========================================================
// changesLeave
//==========================================================
void changesLeave(int &width, int &length)
{
  width = width + 1;
  length = length + 2;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int width = 10;
  int length = 20;

  // Show application header
  cout << "Address operator in parameter" << endl;
  cout << "-----------------------------" << endl << endl;

  // Show column headers
  cout << setw(COLFM1) << left << ""
    << setw(COLFM2) << right << "Width"
    << setw(COLFM2) << right << "Length"
    << endl;

  // Show values before calling changesStay
  cout << setw(COLFM1) << left 
    << "Values before calling changesStay"
    << setw(COLFM2) << right << width
    << setw(COLFM2) << right << length
    << endl;
  changesStay(width, length);

  // Show values after calling changesStay
  cout << setw(COLFM1) << left 
    << "Values after calling changesStay"
    << setw(COLFM2) << right << width
    << setw(COLFM2) << right << length
    << endl;

  // Show values before calling changesLeave
  cout << setw(COLFM1) << left 
    << "Values before calling changesLeave"
    << setw(COLFM2) << right << width
    << setw(COLFM2) << right << length
    << endl;
  changesLeave(width, length);

  // Show values after calling changesLeave
  cout << setw(COLFM1) << left 
    << "Values after calling changesLeave"
    << setw(COLFM2) << right << width
    << setw(COLFM2) << right << length
    << endl;

  // Show application close
  cout << "\nEnd of Address operator in parameter" << endl;

}

//==========================================================
//
// Title: Programmer-defined Functions With Function 
//        Prototypes
// Description:
//   This C++ console application demonstrates programmer-
// defined functions with function prototypes.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Function prototypes
//==========================================================
void showMenu();
void getFloorWidth(double &widthF, double &widthM,
  double lengthF, double lengthM,
  double &areaSF, double &areaSM);
void getFloorLength(double widthF, double widthM,
  double &lengthF, double &lengthM,
  double &areaSF, double &areaSM);
void showFloorArea(double widthF, double widthM,
  double lengthF, double lengthM,
  double areaSF, double areaSM);

//==========================================================
// Globals
//==========================================================
const double FEET_TO_METERS = 0.305;
const int COLFMT1 = 10;
const int COLFMT2 = 26;

//==========================================================
// showMenu
//==========================================================
void showMenu()
{
  cout << "\nFloor Area Estimator" << endl;
  cout << "1 - Enter the floor width" << endl;
  cout << "2 - Enter the floor length" << endl;
  cout << "3 - Show the floor area" << endl;
  cout << "9 - Exit" << endl;
}

//==========================================================
// getFloorWidth
//==========================================================
void getFloorWidth(double &widthF, double &widthM,
  double lengthF, double lengthM,
  double &areaSF, double &areaSM)
{

  // Loop to prompt for and get floor width
  cout << "Enter the floor width (feet): ";
  cin >> widthF;
  while (widthF < 1)
  {
    cout << "Error: floor width has to >= 1."
      << endl;
    cout << "\nEnter the floor width (feet): ";
    cin >> widthF;
  }

  // Recalculate floor width (meters) and areas
  widthM = widthF * FEET_TO_METERS;
  areaSF = widthF * lengthF;
  areaSM = widthM * lengthM;

}

//==========================================================
// getFloorLength
//==========================================================
void getFloorLength(double widthF, double widthM,
  double &lengthF, double &lengthM,
  double &areaSF, double &areaSM)
{

  // Loop to prompt for and get floor length
  cout << "Enter the floor length (feet): ";
  cin >> lengthF;
  while (lengthF < 1)
  {
    cout << "Error: floor length has to >= 1."
      << endl;
    cout << "\nEnter the floor length (feet): ";
    cin >> lengthF;
  }

  // Recalculate floor length (meters) and areas
  lengthM = lengthF * FEET_TO_METERS;
  areaSF = widthF * lengthF;
  areaSM = widthM * lengthM;

}

//==========================================================
// showFloorArea
//==========================================================
void showFloorArea(double widthF, double widthM,
  double lengthF, double lengthM,
  double areaSF, double areaSM)
{
  cout << setw(COLFMT1) << left << ""
    << setw(COLFMT2) << right
    << "Feet and square feet"
    << setw(COLFMT2) << right
    << "Meters and square meters" << endl;
  cout << setw(COLFMT1) << left << "Width:"
    << setw(COLFMT2) << right << widthF
    << setw(COLFMT2) << right << widthM << endl;
  cout << setw(COLFMT1) << left << "Length:"
    << setw(COLFMT2) << right << lengthF
    << setw(COLFMT2) << right << lengthM << endl;
  cout << setw(COLFMT1) << left << "Area:"
    << setw(COLFMT2) << right << areaSF
    << setw(COLFMT2) << right << areaSM << endl;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int option;
  double widthF = 0;
  double lengthF = 0;
  double areaSF = 0;
  double widthM = 0;
  double lengthM = 0;
  double areaSM = 0;

  // Set decimal places
  cout << fixed << setprecision(3);

  // Show application header
  cout << "Welcome to Programmer-defined Functions" << endl;
  cout << "---------------------------------------" << endl;

  // Show menu and get option
  showMenu();
  cout << "\nEnter an option: ";
  cin >> option;

  // Loop to process menu options
  while (option != 9)
  {

    // Test which option selected
    switch (option)
    {

      // Handle floor width
    case 1:
      getFloorWidth(widthF, widthM,
        lengthF, lengthM, areaSF, areaSM);
      break;

      // Handle floor length
    case 2:
      getFloorLength(widthF, widthM,
        lengthF, lengthM, areaSF, areaSM);
      break;

      // Show floor area
    case 3:
      showFloorArea(widthF, widthM,
        lengthF, lengthM, areaSF, areaSM);
      break;

      // Handle unknown option
    default:
      cout << "Error: unknown option of " << option
        << "." << endl;

    }

    // Show menu and get option
    showMenu();
    cout << "\nEnter an option: ";
    cin >> option;

  }
  cout << "Done processing menu options." << endl;

  // Show application close
  cout << "\nEnd of Programmer-defined Functions" << endl;

}

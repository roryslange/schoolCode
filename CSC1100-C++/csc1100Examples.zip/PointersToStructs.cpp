//==========================================================
//
// Title: Pointers to structs
// Description:
//    This C++ console application demonstrates pointers to
// structs.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================

const int COLFMT1 = 16;
const int COLFMT2 = 22;
const int COLFMT3 = 8;

struct employee
{
  int ID;
  string firstName;
  string lastName;
  double hourlyRate;
};

//==========================================================
// printMemoryMap
//==========================================================
void printMemoryMap(employee emp)
{

  // Print column headers
  cout << "\nstruct memory map" << endl;
  cout << setw(COLFMT1) << left << "Field"
    << setw(COLFMT2) << right << "Address (hex)"
    << setw(COLFMT3) << right << "Bytes"
    << endl;

  // Print ID field
  cout << setw(COLFMT1) << left << "ID"
    << setw(COLFMT2) << right << &(emp.ID)
    << setw(COLFMT3) << right << sizeof(emp.ID) 
    << endl;

  // Print first name field
  cout << setw(COLFMT1) << left << "First name"
    << setw(COLFMT2) << right << &(emp.firstName)
    << setw(COLFMT3) << right << sizeof(emp.firstName) 
    << endl;

  // Print last name field
  cout << setw(COLFMT1) << left << "Last name"
    << setw(COLFMT2) << right << &(emp.lastName)
    << setw(COLFMT3) << right << sizeof(emp.lastName) 
    << endl;

  // Print hourly rate field
  cout << setw(COLFMT1) << left << "Hourly rate"
    << setw(COLFMT2) << right << &(emp.hourlyRate)
    << setw(COLFMT3) << right << sizeof(emp.hourlyRate) 
    << endl;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  employee emp;
  employee *empPtr = NULL;

  // Show application header
  cout << "Welcome to Pointers to structs" << endl;
  cout << "------------------------------" << endl;

  // Format financial numbers
  cout << fixed << setprecision(2);

  // Assign values to emp
  emp.ID = 777;
  emp.firstName = "Clem";
  emp.lastName = "Cash";
  emp.hourlyRate = 12.80;
  empPtr = &emp;

  // Print employee information by variable
  cout << "\nEmployee information (by variable)" << endl;
  cout << "ID:              " << emp.ID << endl;
  cout << "First name:      " << emp.firstName << endl;
  cout << "Last name:       " << emp.lastName << endl;
  cout << "Hourly rate ($): " << emp.hourlyRate << endl;

  // Print employee information by pointer variable 
  // and arrow operator
  cout << "\nEmployee information (by pointer variable " 
    << "and arrow operator)" << endl;
  cout << "ID:              " << empPtr->ID << endl;
  cout << "First name:      " << empPtr->firstName << endl;
  cout << "Last name:       " << empPtr->lastName << endl;
  cout << "Hourly rate ($): " << empPtr->hourlyRate << endl;

  // Print employee information by pointer variable
  // and arrow operator
  cout << "\nEmployee information (by pointer variable " 
    << "and dot operator)" << endl;
  cout << "ID:              " << (*empPtr).ID 
    << endl;
  cout << "First name:      " << (*empPtr).firstName 
    << endl;
  cout << "Last name:       " << (*empPtr).lastName 
    << endl;
  cout << "Hourly rate ($): " << (*empPtr).hourlyRate 
    << endl;

  // Print memory map
  printMemoryMap(emp);

  // Show application close
  cout << "\nEnd of Pointers to structs" << endl;

}
 
//==========================================================
//
// Title: Enumerated Types
// Description:
//   This C++ console application demonstrates enumerated 
// types.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global types and variables
//==========================================================

enum t_seasons {UNKNOWN, FALL, WINTER, SPRING, SUMMER};
  // Enumerated type declaration

//enum t_bad_type {1, 2};  
  // Illegal enumerated type declaration
  // Values not valid indentifiers

enum t_weather_conditions {SUNNY, CLOUDY, RAINY, SNOWY}
  g_yesterday;
  // Combined enumerated type and variable declaration
  // Not good style

t_weather_conditions g_today;
  // Global variable of enumerated type
t_weather_conditions g_tomorrow = SNOWY;
  // Global variable of enumerated type with starting value

enum {CIRCLE, TRIANGLE, SQUARE, PENTAGON, HEXAGON} g_shape;
  // Enumerated type without a name (anonymous)

//enum {HEPTAGON, OCTAGON, ENNEAGON, DECAGON} g_figure = OCTAGON;
//  // Illegal enumerated type variable declaration
//  // Cannot specify starting value

//==========================================================
// seasonToString
//==========================================================
string seasonToString(t_seasons s)
{

  // Declare variables
  string str;

  // Test enumerated value
  switch (s)
  {
    case FALL:
      str = "FALL";
      break;
    case WINTER:
      str = "WINTER";
      break;
    case SPRING:
      str = "SPRING";
      break;
    case SUMMER:
      str = "SUMMER";
      break;
    default:
      str = "UNKNOWN";
      break;
  }

  // The following may also be used
  //// Test enumerated value
  //switch (s)
  //{
  //  case 1:
  //    str = "FALL";
  //    break;
  //  case 2:
  //    str = "WINTER";
  //    break;
  //  case 3:
  //    str = "SPRING";
  //    break;
  //  case 4:
  //    str = "SUMMER";
  //    break;
  //  default:
  //    str = "UNKNOWN";
  //    break;
  //}

  return str;

}

//==========================================================
// stringToSeason
//==========================================================
t_seasons stringToSeason(string str)
{

  // Declare variables
  t_seasons s;

  // Test string
  if (str == "FALL")
    s = FALL;
  else if (str == "WINTER")
    s = WINTER;
  else if (str == "SPRING")
    s = SPRING;
  else if (str == "SUMMER")
    s = SUMMER;
  else
    s = UNKNOWN;

  return s;

}

//==========================================================
// indexToSeason
//==========================================================
t_seasons indexToSeason(int i)
{
  if (i < 1 || i > 4)
    return UNKNOWN;
  else
    return (t_seasons) i;
}

//==========================================================
// seasonToIndex
// This function not necessary since enumerated type 
// variable already behaves as integer.
//==========================================================
int seasonToIndex(t_seasons s)
{
    return s;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  t_seasons season1;
  t_seasons season2 = SUMMER;
  int seasonIndex;
  string str;
  int index;

  // Show application header
  cout << "Welcome to Function Enumerated Types" << endl;
  cout << "------------------------------------" << endl 
    << endl;

  // Assign to and print enumerated type variable
  cout << "Assignment statement" << endl;
  season1 = FALL;
  cout << "season1: " << seasonToString(season1) 
       << " (" << season1 << ")" << endl;

  // Prompt for and get season string
  cout << "\nConversion from string to season" << endl;
  cout << "Enter a season string (FALL, WINTER, SPRING, SUMMER): ";
  cin >> str;
  season1 = stringToSeason(str);
  cout << "season1: " << seasonToString(season1)
       << " (" << season1 << ")" << endl;

  // Prompt for and get season index
  cout << "\nConversion from index to season" << endl;
  cout << "Enter a season index (1-FALL, 2-WINTER, " 
    << "3-SPRING, 4-SUMMER): ";
  cin >> index;
  season1 = indexToSeason(index);
  cout << "season1: " << seasonToString(season1)
    << " (" << season1 << ")" << endl;

  // Loop through each enumerated type value
  cout << "\nAssignment statement loop" << endl;
  for (int i = 0; i <= sizeof(t_seasons); i++)
  {

    // Convert from index to season
    season1 = (t_seasons) i;

    // Print enumerated type value
    cout << "season1: " << seasonToString(season1)
         << " (" << season1 << ")" << endl;

  }

  // Test enumerated type variables
  cout << "\nEnumerated type variable test" << endl;

  season1 = FALL;
  season2 = WINTER;
  cout << "season1: "
       << seasonToString(season1)
       << " (" << season1 << ")" << endl;
  cout << "season2: "
    << seasonToString(season2)
    << " (" << season2 << ")" << endl;

  // Compare enumerated type variables
  if (season1 < season2)
    cout << "season1 is 'less than' season2" 
      << endl;
  else if (season1 == season2)
    cout << "season1 is 'equal to' season2"
      << endl;
  else // (season > season2)
    cout << "season1 is 'greater than' season2" 
      << endl;

  // Assign enumerated type values to global variables
  g_yesterday = RAINY;
  g_today = CLOUDY;
  g_tomorrow = SNOWY;
  g_shape = CIRCLE;

  // Print global variable values
  cout << "\nGlobal variable values" << endl;
  cout << "g_yesterday: " << g_yesterday << endl;
  cout << "g_today:     " << g_today << endl;
  cout << "g_tomorrow:  " << g_tomorrow << endl;
  cout << "g_shape:     " << g_shape << endl;

  // Show application close
  cout << "\nEnd of Enumerated Types" << endl;

}

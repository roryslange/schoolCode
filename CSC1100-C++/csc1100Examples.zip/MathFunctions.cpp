//==========================================================
//
// Title: Math Functions
// Description:
//   This C++ console application shows some math functions.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT1 = 34;
  const int COLFMT2 = 30;

  // Declare variables
  float rNum;
  int iNum;

  // Format real numbers
  cout << fixed << setprecision(2);

  // Show application header
  cout << "Welcome to Math Functions" << endl;
  cout << "-------------------------" << endl << endl;

  // Prompt user for and get two numbers
  cout << "Enter a real number: ";
  cin >> rNum;
  cout << "Enter an integer: ";
  cin >> iNum;

  // Show column headers
  cout << endl;
  cout << setw(COLFMT1) << left << "Data/Function"
    << setw(COLFMT2) << right << "Value" << endl;

  // Echo inputs
  cout << endl;
  cout << setw(COLFMT1) << left << "Real number:"
    << setw(COLFMT2) << right << rNum << endl;
  cout << setw(COLFMT1) << left << "Integer:"
    << setw(COLFMT2) << right << iNum << endl;

  // Show some math functions
  cout << endl;
  cout << setw(COLFMT1) << left << "cos(real number):"
    << setw(COLFMT2) << right << cos(rNum) << endl;
  cout << setw(COLFMT1) << left << "sin(real number):"
    << setw(COLFMT2) << right << sin(rNum) << endl;
  cout << setw(COLFMT1) << left << "cosh(real number):"
    << setw(COLFMT2) << right << cosh(rNum) << endl;
  cout << setw(COLFMT1) << left << "sinh(real number):"
    << setw(COLFMT2) << right << sinh(rNum) << endl;

  cout << endl;
  cout << setw(COLFMT1) << left 
    << "pow(real number, integer):"
    << setw(COLFMT2) << right << pow(rNum, iNum) << endl;
  cout << setw(COLFMT1) << left << "sqrt(integer):"
    << setw(COLFMT2) << right << sqrt(iNum) << endl;
  cout << setw(COLFMT1) << left << "cbrt(integer):"
    << setw(COLFMT2) << right << cbrt(iNum) << endl;

  cout << endl;
  cout << setw(COLFMT1) << left << "ceil(real number):"
    << setw(COLFMT2) << right << ceil(rNum) << endl;
  cout << setw(COLFMT1) << left << "floor(real number):"
    << setw(COLFMT2) << right << floor(rNum) << endl;
  cout << setw(COLFMT1) << left << "trunc(real number):"
    << setw(COLFMT2) << right << trunc(rNum) << endl;
  cout << setw(COLFMT1) << left << "round(real number):"
    << setw(COLFMT2) << right << round(rNum) << endl;
  cout << setw(COLFMT1) << left << "abs(real number):"
    << setw(COLFMT2) << right << abs(rNum) << endl;

  cout << endl;
  cout << setw(COLFMT1) << left 
    << "isfinite(real number):"
    << setw(COLFMT2) << right 
    << (isfinite(rNum) ? "yes" : "no") << endl;
  cout << setw(COLFMT1) << left 
    << "isnan(real number):"
    << setw(COLFMT2) << right 
    << (isnan(rNum) ? "yes" : "no") << endl;
  cout << setw(COLFMT1) << left 
    << "isgreater(real number > integer):"
    << setw(COLFMT2) << right 
    << (isgreater(rNum, iNum) ? "yes" : "no") << endl;

  // Show application close
  cout << "\nEnd of Math Functions" << endl;

}

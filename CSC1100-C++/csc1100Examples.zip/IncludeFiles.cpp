//==========================================================
//
// Title: Include Files
// Description:
//   This C++ console application demonstrates 
// programmer-defined include files.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
#include "ProgrammerLibrary.h" // For programmer-defined library
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global constants
//==========================================================
const int COLFMT1 = 16;
const int COLFMT2 = 20;

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  string product;
  double subtotal;
  string state;
  double tax;
  double total;

  // Show application header
  cout << "Welcome to Include Files" << endl;
  cout << "------------------------" << endl << endl;

  // Set real-number formatting
  cout << fixed << setprecision(2);

  // Prompt for and get product sold
  cout << "Enter product sold: ";
  getline(cin, product);

  // Prompt for and get sale amount
  cout << "Enter sale amount ($): ";
  cin >> subtotal;

  // Prompt for and get state
  cout << "Enter a two-character state code: ";
  cin >> state;
  state = upperCase(state);

  // Calculate sales tax and total
  tax = salesTax(state, subtotal);
  total = subtotal + tax;

  // Print sale information
  cout << "\nSale information" << endl;
  cout << setw(COLFMT1) << left << "Product:"
    << setw(COLFMT2) << right << product << endl;
  cout << setw(COLFMT1) << left << "Subtotal ($):"
    << setw(COLFMT2) << right << subtotal << endl;
  cout << setw(COLFMT1) << left << "State:"
    << setw(COLFMT2) << right << state << endl;
  cout << setw(COLFMT1) << left << "Sales tax ($):"
    << setw(COLFMT2) << right << tax << endl;
  cout << setw(COLFMT1) << left << "Total ($):"
    << setw(COLFMT2) << right << total << endl;

  // Show application close
  cout << "\nEnd of Include Files" << endl;

}

//==========================================================
//
// Title: Namespaces
// Description:
//   This C++ console application demonstrates 
// programmer-defined namespaces.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Global variables
//==========================================================
const int COLFMT1 = 20;
const int COLFMT2 = 8;

//==========================================================
// Global namespaces n_2018
//==========================================================
namespace n_2018
{
  const double IRS_REIMBURSEMENT_RATE = 0.545;  // dollars per mile
  double reimbursementAmount(double miles)
  {
    return miles * 
      IRS_REIMBURSEMENT_RATE;
  }
}

//==========================================================
// Global namespaces n_2019
//==========================================================
namespace n_2019
{
  const double IRS_REIMBURSEMENT_RATE = 0.58;  // dollars per mile
  const double COMPANY_REIMBURSEMENT_RATIO = 1.1;  // ratio
  double reimbursementAmount(double miles)
  {
    return miles * 
      IRS_REIMBURSEMENT_RATE * 
      COMPANY_REIMBURSEMENT_RATIO;
  }

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int year;
  double miles;
  double reimbursement;

  // Show application header
  cout << "Welcome to Namespaces" << endl;
  cout << "---------------------" << endl << endl;

  // Set real-number formatting
  cout << fixed << setprecision(2);

  // Loop to calculate expenses
  cout << "Enter reimbursement year (0 to exit): ";
  cin >> year;
  while (year != 0)
  {

    // Prompt for and get miles driven
    cout << "Enter reimbursement miles: ";
    cin >> miles;

    // Calculate expense
    if (year == 2018)
      reimbursement = n_2018::reimbursementAmount(miles);
    else if (year == 2019)
      reimbursement = n_2019::reimbursementAmount(miles);
    else
      reimbursement = -999;

    // Print expense information
    cout << "\nReimbursement information" << endl;
    cout << setw(COLFMT1) << left << "Year:"
      << setw(COLFMT2) << right << year << endl;
    cout << setw(COLFMT1) << left << "Miles:"
      << setw(COLFMT2) << right << miles << endl;
    cout << setw(COLFMT1) << left << "Reimbursement ($)"
      << setw(COLFMT2) << right << reimbursement << endl;

    // Get next year
    cout << "\nEnter reimbursement year (0 to exit): ";
    cin >> year;

  }

  // Show application close
  cout << "\nEnd of Namespaces" << endl;

}

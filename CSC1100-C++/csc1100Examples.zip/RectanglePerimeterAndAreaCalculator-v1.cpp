//==========================================================
//
// Title: Rectangle Perimeter and Area Calculator, v1
// Description:
//   This C++ console application calculates the perimeter 
// and area of a rectangle.  It prompts for and gets from 
// the user the length and width of the rectangle, and 
// calculates and prints the area and perimeter.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  double length;
  double width;
  double perimeter;
  double area;

  // Show application header
  cout << "Welcome to Rectangle Perimeter and Area " 
    << "Calculator, v1" << endl;
  cout << "----------------------------------------"
    << "--------------" << endl << endl;

  // Prompt for and get length
  cout << "Enter the length (meters): ";
  cin >> length;

  // Prompt for and get width
  cout << "Enter the width (meters): ";
  cin >> width;

  // Calculate perimeter and area
  perimeter = 2 * (length + width);
  area = length * width;

  // Show inputs and outputs
  cout << "\nLength:    " << length << " meters" << endl;
  cout << "Width:     " << width << " meters" << endl;
  cout << "Perimeter: " << perimeter << " meters" << endl;
  cout << "Area:      " << area << " square meters" << endl;

  // Show application close
  cout << "\nEnd of Rectangle Perimeter and Area " 
    << "Calculator, v1" << endl;

}

//==========================================================
//
// Title: Integer-to-Character Mapping
// Description:
//   This C++ console application shows the integers from 
// 0 to 255 and their corresponding characters.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const int COLFMT1 = 10;

  // Show application header
  cout << "Welcome to Integer-to-Character Mapping" << endl;
  cout << "---------------------------------------" << endl
    << endl;

  // Loop to show each character
  cout << setw(COLFMT1) << right << "Integer" 
    << setw(COLFMT1) << right << "Character" << endl;
  for (int i = 0; i < 256; i++)
  {
    cout << setw(COLFMT1) << right << i 
      << setw(COLFMT1) << right << (char) i << endl;
  }

  // Show application close
  cout << "\nEnd of Integer-to-Character Mapping" << endl;

}

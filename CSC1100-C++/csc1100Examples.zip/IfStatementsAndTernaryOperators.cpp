//==========================================================
//
//  Title: if Statements and Ternary Operators
//  Description:
//    This C++ console application demonstrates if 
// statements and ternary operators.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int age;
  string str;
  int iNum;
  char type;
  int year;
  int days;

  // Show application header
  cout << "Welcome to if Statements and Ternary Operators" 
    << endl;
  cout << "----------------------------------------------" 
    << endl << endl;

  // Test voting age
  cout << "If-then" << endl;
  cout << "Enter an age: ";
  cin >> age;

  // No curly braces required here
  if (age >= 18)
    cout << "You can vote!" << endl;

  // No curly braces required here either
  if (age >= 18)
  {
    cout << "You can vote!" << endl;
  }

  // Test string length
  cout << "\nIf-then" << endl;
  cout << "Enter a string with at least ten characters: ";
  cin >> str;
  if (str.length() <= 10)
  {

    // Curly braces needed for this block
    cout << "Error: that string isn't long enough." << endl;
    cout << "The string needs " << (10 - str.length()) 
      << " more characters." << endl;

  }

  // Test whether a number is even or odd
  cout << "\nIf-then-else" << endl;
  cout << "Enter a whole number: ";
  cin >> iNum;
  if (iNum % 2 == 0)
   cout << iNum << " is an even number." << endl;
  else
   cout << iNum << " is an odd number." << endl;

  // Test whether a number is within a range or not
  cout << "\nIf-then-elseif-else" << endl;
  cout << "Enter a whole number in the range 1-100: ";
  cin >> iNum;
  if (iNum < 1)
    cout << iNum << " is less than range 1-100." << endl;
  else if (iNum <= 100)
    cout << iNum << " is within range 1-100." << endl;
  else
    cout << iNum << " is greater than range 1-100." << endl;

  // Test which gas type entered
  cout << "\nIf-then-elseif-elseif-else" << endl;
  cout 
   << "Enter a gas type (r-regular, m-mid-grade, p-premium): ";
  cin >> type;
  if (type == 'r')
   cout 
     << "Gas type 'regular' has an octane rating of 87." 
     << endl;
  else if (type == 'm')
   cout 
     << "Gas type 'mid-grade' has an octane rating of 89." 
     << endl;
  else if (type == 'p')
   cout 
     << "Gas type 'premium' has an octane rating of 92." 
     << endl;
  else
   cout << "'" << type << "' is an unknown gas type." 
     << endl;

  // Ternary operator in cout statement
  cout << "\nTernary operator in cout statement" << endl;
  cout << "Enter the number of days before the event: ";
  cin >> days;

  // Handling logic with ternary operator
  cout << "The event will happen in " << days
    << (days == 1 ? " day." : " days.") << endl;

  // Handling same logic with if statement
  if (days == 1)
    cout << "The event will happen in " << days << " day.";
  else
    cout << "The event will happen in " << days << " days.";

  // Ternary operator in assignment statement
  cout << "\nTernary operator in assignment statement" 
    << endl;
  cout << "Enter a negative number: ";
  cin >> iNum;
  iNum = (iNum > 0 ? -iNum : iNum);  
    // Convert number to negative if not entered that way
  cout << "Negative number: " << iNum << endl;

  // Used = instead of ==
  // AKA Used assignment statement instead of condition
  // Condition (year = 2020) is actually an assignment 
  // statement which evaluates to:
  //   TRUE if righthand side is nonzero.
  //   FALSE if righthand side is zero.
  //cout << "\nAssignment statement instead of condition"
  //  << endl;
  //cout << "Enter a year: ";
  //cin >> year;
  //if (year = 2020)
  //  cout << "You entered the year 2020!" << endl;
  //else
  //  cout << "You entered a year other than 2020!" << endl;

  // Show application close
  cout << "\nEnd of if Statements and Ternary Operators" 
    << endl;

}

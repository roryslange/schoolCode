//==========================================================
//
//  Title: Formatted Output
//  Description:
//    This C++ console application shows formatted outputs.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const string RULER60 = 
    "123456789012345678901234567890123456789012345678901234567890";
  const int COLFMT1 = 28;
  const int COLFMT2 = 10;
  const int COLFMT3 = 4;
  const int COLFMT4 = 10;
  const int COLFMT5 = 6;
  const int COLFMT6 = 8;

  // Declare variables
  int i1 = 17;
  int i2 = 2020;
  double d1 = 6;
  double d2 = .25;
  double d3 = 4 / 6.;
  string p01 = "George Washington";
  string p16 = "Abraham Lincoln";

  // Show application header
  cout << "Welcome to Formatted Output" << endl;
  cout << "---------------------------" << endl << endl;

  // Show formatted strings
  cout << "1) Formatted strings" << endl << endl;
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT1 << ", left)" << endl;
  cout << setw(COLFMT1) << left << p01
    << setw(COLFMT1) << left << p16
    << "#" << endl;
  cout << "Column spec: (" << COLFMT1 << ", right)" << endl;
  cout << setw(COLFMT1) << right << p01
    << setw(COLFMT1) << right << p16
    << "#" << endl << endl;

  // Show formatted numbers in default format
  cout << "2) Formatted numbers in default format "
    << endl << "(reals up to 6 decimal places with "
    << "optional decimal point)" << endl << endl;
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT2 << ", left)" << endl;
  cout << setw(COLFMT2) << left << i1
    << setw(COLFMT2) << left << i2
    << setw(COLFMT2) << left << d1
    << setw(COLFMT2) << left << d2
    << setw(COLFMT2) << left << d3
    << "#" << endl;
  cout << "Column spec: (" << COLFMT2 << ", right)" << endl;
  cout << setw(COLFMT2) << right << i1
    << setw(COLFMT2) << right << i2
    << setw(COLFMT2) << right << d1
    << setw(COLFMT2) << right << d2
    << setw(COLFMT2) << right << d3
    << "#" << endl << endl;

  // Show formatted numbers with reals up to 3 decimal places
  cout << "3) Formatted reals up to 3 decimal places "
    << "\nwith optional decimal point" << endl << endl;
  cout << setprecision(3);
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT2 << ", left)" << endl;
  cout << setw(COLFMT2) << left << i1
    << setw(COLFMT2) << left << i2
    << setw(COLFMT2) << left << d1
    << setw(COLFMT2) << left << d2
    << setw(COLFMT2) << left << d3
    << "#" << endl;
  cout << "Column spec: (" << COLFMT2 << ", right)" << endl;
  cout << setw(COLFMT2) << right << i1
    << setw(COLFMT2) << right << i2
    << setw(COLFMT2) << right << d1
    << setw(COLFMT2) << right << d2
    << setw(COLFMT2) << right << d3
    << "#" << endl << endl;

  // Show formatted numbers with reals with exactly 2 decimal places
  cout << "4) Formatted reals with exactly 2 decimal "
    << "places" << endl << endl;
  cout << fixed << setprecision(2);
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT2 << ", left)" << endl;
  cout << setw(COLFMT2) << left << i1
    << setw(COLFMT2) << left << i2
    << setw(COLFMT2) << left << d1
    << setw(COLFMT2) << left << d2
    << setw(COLFMT2) << left << d3
    << "#" << endl;
  cout << "Column spec: (" << COLFMT2 << ", right)" << endl;
  cout << setw(COLFMT2) << right << i1
    << setw(COLFMT2) << right << i2
    << setw(COLFMT2) << right << d1
    << setw(COLFMT2) << right << d2
    << setw(COLFMT2) << right << d3
    << "#" << endl << endl;

  // Return formatted numbers to default format
  cout << "5) Formatted numbers returned to default format "
    << endl << "(reals up to 6 decimal places with "
    << "optional decimal point)" << endl << endl;
  cout.unsetf(ios::fixed);
  cout << setprecision(0);
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT2 << ", left)" << endl;
  cout << setw(COLFMT2) << left << i1
    << setw(COLFMT2) << left << i2
    << setw(COLFMT2) << left << d1
    << setw(COLFMT2) << left << d2
    << setw(COLFMT2) << left << d3
    << "#" << endl;
  cout << "Column spec: (" << COLFMT2 << ", right)" << endl;
  cout << setw(COLFMT2) << right << i1
    << setw(COLFMT2) << right << i2
    << setw(COLFMT2) << right << d1
    << setw(COLFMT2) << right << d2
    << setw(COLFMT2) << right << d3
    << "#" << endl << endl;

  // Show formatted data with column width set too low
  cout << "6) Formatted data with column width set "
    << "too low" << endl << endl;
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT3 << ", left)" << endl;
  cout << setw(COLFMT3) << left << p01
    << setw(COLFMT3) << left << p16
    << "#" << endl << endl;

  // Return formatted numbers to default format
  cout << "7) Formatted data in three columns" << endl 
    << endl;
  cout << fixed << setprecision(3);
  cout << RULER60 << endl;
  cout << "Column specs: (" << COLFMT4 << ", left), "
    << "(" << COLFMT5 << ", right), "
    << "(" << COLFMT6 << ", right), "
    << "precision=3,fixed" << endl;
  cout << "Car models in movies" << endl;

  cout << setw(COLFMT4) << left << "Model"
    << setw(COLFMT5) << right << "Year"
    << setw(COLFMT6) << right << "Rating"
    << endl;

  cout << setw(COLFMT4) << left << "Cadillac"
    << setw(COLFMT5) << right << 1959
    << setw(COLFMT6) << right << 2.3
    << endl;

  cout << setw(COLFMT4) << left << "DeLorean"
    << setw(COLFMT5) << right << 1982
    << setw(COLFMT6) << right << 4.13
    << endl;

  cout << setw(COLFMT4) << left << "Explorer"
    << setw(COLFMT5) << right << 1993
    << setw(COLFMT6) << right << 3.1666
    << endl << endl;

  // Return formatted numbers to default format
  cout << "8) Formatted numbers using printf" << endl
    << endl;

  // Show formatted numbers
  cout << RULER60 << endl;
  cout << "Column spec: (" << COLFMT2 << ", left)" << endl;
  printf("%-8d%-8.1f%-8.2f%-8.4f\n", i1, d1, d2, d3);
  cout << "Column spec: (" << COLFMT2 << ", right)" << endl;
  printf("%8d%8.1f%8.2f%8.4f\n", i2, d1, d2, d3);

  // Show application close
  cout << "\nEnd of Formatted Output" << endl;

}

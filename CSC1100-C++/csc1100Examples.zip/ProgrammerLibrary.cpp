 //==========================================================
//
// Title: Programmer Library Implementation
// Description:
//   This C++ implementation file is paired with a header
// file of the same name.  The header file may be included 
// in any C++ application.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
#include "ProgrammerLibrary.h" // For programmer-defined library
using namespace std;

//==========================================================
// Global constants
//==========================================================
const double MI_SALES_TAX_RATE = 6.0;
const double OH_SALES_TAX_RATE = 5.75;
const double IN_SALES_TAX_RATE = 7.0;

//==========================================================
// salesTax
//==========================================================
double salesTax(string state, double subtotal)
{

  // Declare variables
  double sales_tax_rate;
  
  // Set sales tax rate
  if (state == "MI")
    sales_tax_rate = MI_SALES_TAX_RATE;
  else if (state == "OH")
    sales_tax_rate = OH_SALES_TAX_RATE;
  else if (state == "IN")
    sales_tax_rate = IN_SALES_TAX_RATE;
  else
    return -99;

  // Return subtotal
  return subtotal * sales_tax_rate / 100;

}

//==========================================================
// upperCase
//==========================================================
string upperCase(string str)
{
  for (int i = 0; i < str.length(); i++)
    str[i] = toupper(str[i]);
  return str;
}

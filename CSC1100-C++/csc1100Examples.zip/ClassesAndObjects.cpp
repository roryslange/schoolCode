//==========================================================
//
// Title: Classes and Objects
// Description:
//   This C++ console application shows a class definition
// and objects created from the class.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout", for example.

//==========================================================
// Globals
//==========================================================

// Declare constants
const int COLFMT = 20;
const string BORDER = "----------------------------------------";

//==========================================================
// Boat class
//==========================================================
class Boat
{

  //--------------------------------------------------------
  // Private members
  //--------------------------------------------------------
  private:

    // Declare fields
    string name;
    int length;

  //--------------------------------------------------------
  // Public members
  //--------------------------------------------------------
  public:

    //------------------------------------------------------
    // Constructors
    //------------------------------------------------------

    // No-parameter constructor
    Boat()
    {
      cout << "\nNo-parameter constructor called." << endl;
      name = "(not set)";
      length = -1;
    }

    // One-parameter constructor
    Boat(string name)
    {
      cout << "\nOne-parameter constructor called." << endl;
      this->name = name;
      length = -1;
    }

    // Two-parameter constructor
    Boat(string name, int length)
    {
      cout << "\nTwo-parameter constructor called." << endl;
      this->name = name;
      this->length = length;
    }

    //------------------------------------------------------
    // Setters
    //------------------------------------------------------

    // setLength
    void setLength(int length)
    {
      this->length = length;
    }

    // setName
    void setName(string name)
    {
      this->name = name;
    }

    //------------------------------------------------------
    // Getters
    //------------------------------------------------------

    // getLength
    int getLength()
    {
      return length;
    }

    // getName
    string getName()
    {
      return name;
    }

};

//==========================================================
// printInfo
//==========================================================
void printInfo(string heading, Boat b)
{
  cout << endl << heading << endl;
  cout << setw(COLFMT) << left << "Name:"
    << setw(COLFMT) << right << b.getName() << endl;
  cout << setw(COLFMT) << left << "Length (feet):"
    << setw(COLFMT) << right << b.getLength() << endl;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  string name;
  int length;

  // Show application header
  cout << "Welcome to Classes and Objects" << endl;
  cout << "==============================" << endl;

  // Create and set boat 1 info
  cout << "\nBoat 1" << endl;
  cout << BORDER << endl;
  Boat b1;
  printInfo("Boat 1 after no-parameter constructor.", b1);
  b1.setName ("Rosebud");
  b1.setLength (42);
  printInfo("Boat 1 after setting both fields", b1);

  // Create and set boat 2 info
  cout << "\nBoat 2" << endl;
  cout << BORDER << endl;
  Boat b2("Mayflower");
  printInfo("Boat 2 after one-parameter constructor.", b2);
  cout << "\nEnter length of boat 2 (feet): ";
  cin >> length;
  b2.setLength(length);
  printInfo("Boat 2 after prompting for one field", b2);

  // Create and set boat 3 info
  cout << "\nBoat 3" << endl;
  cout << BORDER << endl;
  Boat b3("SS Minnow", 60);
  printInfo("Boat 3 after two-parameter constructor.", b3);

  // Show application close
  cout << "\nEnd of Classes and Objects" << endl;

}

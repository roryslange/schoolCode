//==========================================================
//
// Title: Cities
// Description:
//   This C++ console application demonstrates parallel 
// arrays.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// menuOption
//==========================================================
int menuOption()
{

  // Declare variables
  int option;

  // Show menu and get option
  cout << endl;
  cout << "City Menu" << endl;
  cout << "1 - Add city" << endl;
  cout << "2 - List cities" << endl;
  cout << "3 - Delete city" << endl;
  cout << "9 - Exit" << endl << endl;
  cout << "Enter an option: ";
  cin >> option;

  // Return dimension
  return option;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare constants
  const int ARRAY_SIZE = 5;

  // Declare variables
  int option;
  string cities[ARRAY_SIZE];
  string states[ARRAY_SIZE];
  int cityCount = 0;

  // Show application header
  cout << "Welcome to Cities" << endl;
  cout << "-----------------" << endl;

  // Loop to process menu options
  option = menuOption();
  while (option != 9)
  {

    // Add city
    if (option == 1)
    {

      // Test if space to add city
      if (cityCount == ARRAY_SIZE)
        cout << "Error: cannot add a city at this time." 
          << endl;
      else
      {

        // Prompt for and get city to add
        cout << "Enter a city (no spaces): ";
        cin >> cities[cityCount];
        cout << "Enter a two-letter state code: ";
        cin >> states[cityCount];
        cout << "City added: " << cities[cityCount] << ", "
          << states[cityCount] << endl;
        cityCount = cityCount + 1;

      }

    }

    // 2-List cities
    else if (option == 2)
    {
      cout << endl << "City List" << endl;
      cout << setw(14) << left << "City" 
        << setw(4) << left << "State" << endl;
      for (int i = 0; i < cityCount; i++)
      {
        cout << setw(14) << left << cities[i] 
          << setw(4) << left << states[i] << endl;
      }
      cout << "\nCities: " << cityCount
        << endl;
    }
     
    // 3-Delete city
    else if (option == 3)
    {

      // Test if city to delete
      if (cityCount == 0)
        cout << "Error: there is no city to delete." 
          << endl;
      else
      {

        // Delete city
        cout << "City deleted: " << cities[cityCount - 1] 
          << ", " << states[cityCount - 1] << endl;
        cityCount = cityCount - 1;

      }

    }

    // Handle unknown option
    else
    {
      cout << "Invalid option of '" << option << "'." 
        << endl;
    }

    // Get next option
    option = menuOption();

  }

  // Show application close
  cout << "\nEnd of Cities" << endl;

}

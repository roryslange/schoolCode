//==========================================================
//
// Title: Arrays - Linear and Binary Searches
// Description:
//   This C++ console application shows linear and binary 
// searches.  It sorts the array using a select sort before 
// performing the binary search.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int ARRAY_SIZE = 10;
const int RANDOM_UPPER = 12;
const int VALUE_NOT_FOUND = RANDOM_UPPER + 1;
const int COLFMT = 20;
int linearCycles = 0;
int binaryCycles = 0;

//==========================================================
// Function prototypes
//==========================================================
int binarySearch(int[], int, int);
int linearSearch(int[], int, int);
void printArray(string, int[], int);
void randomizeArray(int[], int, int);
void selectionSort(int[], int);

//==========================================================
// binarySearch
// Returns index if key found in array, otherwise returns 
// -1.
//==========================================================
int binarySearch(int array[], int arraySize, int key)
{

  // Declare variables
  int min = 0;
  int index;
  int max = arraySize - 1;

  // Loop to find key
  while (min <= max)
  {

    // Get midpoint of array
    index = (min + max) / 2;

    // Test if key found
    if (array[index] == key)  // Guess is right on
      return index;
    else if (array[index] < key)  // Guess too low
      min = index + 1;
    else
      max = index - 1;
    binaryCycles = binaryCycles + 1;

  }

  // Return index
  return -1;

}

//==========================================================
// linearSearch
// Returns index if key found in array, otherwise returns 
// -1.
//==========================================================
int linearSearch(int array[], int arraySize, int key)
{

  // Declare variables
  int index = 0;

  // Loop to validate dimension
  while (index < arraySize && array[index] != key)
  {
    index = index + 1;
    linearCycles = linearCycles + 1;
  }

  // Return index
  if (index == arraySize)
    return -1;
  else
    return index;

}

//==========================================================
// printArray
//==========================================================
void printArray(string heading, int array[], int arraySize)
{
  cout << "\n" << heading << endl;
  cout << setw(COLFMT) << right << "Index" 
    << setw(COLFMT) << right << "Integer" << endl;
  for (int n = 0; n < arraySize; n++)
    cout << setw(COLFMT) << right << n 
      << setw(COLFMT) << right << array[n] << endl;
}

//==========================================================
// randomizeArray
//==========================================================
void randomizeArray(int arr[], int arrSize,
  int upperLimit)
{

  // Initialize random number generator
  srand(time(NULL));

  // Loop to generate and store random numbers in array
  for (int i = 0; i < arrSize; i++)
    arr[i] = rand() % upperLimit + 1;
  cout << "Randomized numbers in the range 1 to "
    << upperLimit << " stored in array." << endl;

}

//==========================================================
// selectionSort
//==========================================================
void selectionSort(int array[], int arraySize)
{
  
  // Declare variables
  int minIndex;
  int temp;

  // Loop to handle unsorted part of array
  for (int i = 0; i < arraySize - 1; i++)
  {

    // Loop to find lowest number in unsorted part of array
    minIndex = i;
    for (int j = i + 1; j < arraySize; j++) 
      if (array[j] < array[minIndex]) 
        minIndex = j;

    // Test if lower number found
    if (minIndex != i)
    {

      // Swap values in two array elements
      temp = array[i];
      array[i] = array[minIndex];
      array[minIndex] = temp;
  
    }

  }

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int numbers[ARRAY_SIZE];

  // Set real number format
  cout << fixed << setprecision(0);

  // Show application header
  cout << "Welcome to Arrays - Linear and Binary Searches" 
    << endl;
  cout << "----------------------------------------------" 
    << endl << endl;

  // Place random numbers in array
  randomizeArray(numbers, ARRAY_SIZE, RANDOM_UPPER);

  // Print numbers in array
  printArray("Unsorted Array", numbers, ARRAY_SIZE);

  //--------------------------------------------------------
  // Linear search
  //--------------------------------------------------------

  // Search for each value in array
  cout << "\nLinear search (index -1 means not found)" 
    << endl;
  cout << setw(COLFMT) << right << "Search Value" 
    << setw(COLFMT) << right << "Index where found" 
    << endl;
  linearCycles = 0;
  for (int n = 0; n < ARRAY_SIZE; n++)
    cout << setw(COLFMT) << right << numbers[n] 
      << setw(COLFMT) << right 
      << linearSearch(numbers, ARRAY_SIZE, numbers[n]) 
      << endl;

  // Search for value not in array
  cout << setw(COLFMT) << right << VALUE_NOT_FOUND
    << setw(COLFMT) << right
    << linearSearch(numbers, ARRAY_SIZE, VALUE_NOT_FOUND) 
    << endl;

  //--------------------------------------------------------
  // Binary search
  //--------------------------------------------------------

  // Sort numbers in array
  selectionSort(numbers, ARRAY_SIZE);
  cout << "\nArray sorted using select sort." << endl;

  // Print numbers in array
  printArray("Sorted Array", numbers, ARRAY_SIZE);

  // Search for each value in array
  cout << "\nBinary search (index -1 means not found)" 
    << endl;
  cout << setw(COLFMT) << right << "Search Value" 
    << setw(COLFMT) << right << "Index where found" 
    << endl;
  binaryCycles = 0;
  for (int n = 0; n < ARRAY_SIZE; n++)
    cout << setw(COLFMT) << right << numbers[n] 
      << setw(COLFMT) << right
      << binarySearch(numbers, ARRAY_SIZE, numbers[n]) 
      << endl;

  // Search for value not in array
  cout << setw(COLFMT) << right << VALUE_NOT_FOUND
    << setw(COLFMT) << right
    << binarySearch(numbers, ARRAY_SIZE, VALUE_NOT_FOUND)
    << endl;

  //--------------------------------------------------------
  // Search results
  //--------------------------------------------------------

  // Show elapsed times
  cout << "\nSearch cycles" << endl;
  cout << "Cycles to perform " << ARRAY_SIZE + 1 
    << " searches" << endl;
  cout << setw(COLFMT) << left << "-Linear search:"
    << setw(COLFMT) << right << linearCycles << endl;
  cout << setw(COLFMT) << left << "-Binary search:"
    << setw(COLFMT) << right << binaryCycles << endl;
  cout << "Binary takes " 
    << (double) binaryCycles / linearCycles * 100 
    << "% of the cycles as linear to do " << ARRAY_SIZE + 1 
    << " searches." << endl;

  // Show application close
  cout << "\nEnd of Arrays - Linear and Binary Searches" 
    << endl;

}

//==========================================================
//
// Title: couts
// Description:
//   This C++ console application shows couts.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int iNum = 7;
  double rNum = 8.5;
  string name = "Wendy";

  // Show application header
  cout << "Welcome to couts" << endl;
  cout << "----------------" << endl << endl;

  // Show cout statements
  cout << "One string." << endl;
  cout << "One \"string\".  " << "Another string." << endl;
  cout << "Number: " << 44 << endl;
  cout << "Formula: " << 22. / 7 << endl;
  cout << "Integer variable: " << iNum << endl;
  cout << "Real-number variable: " << rNum << endl;
  cout << "Formula: " << iNum + rNum << endl;
  cout << "String variable: " << name << endl;

  // Show application close
  cout << "\nEnd of couts" << endl;

}

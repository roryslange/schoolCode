//==========================================================
//
// Title: Arithmetic Expressions
// Description:
//   This C++ console application shows the results of 
// various arithmetic expressions.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Show application header
  cout << "Welcome to Arithmetic Expressions" << endl;
  cout << "---------------------------------" << endl 
    << endl;

  // Show arithmetic expression results
  cout << "Expression 1" << endl;
  cout << "2 + 3 * 5 = " << (2 + 3 * 5) << endl;

  cout << "\nExpression 2" << endl;
  cout << "12.8 * 17.5 - 34.50 = "
    << (12.8 * 17.5 - 34.50) << endl;

  cout << "\nExpression 3" << endl;
  cout << "2 + 3.5 = " << (2 + 3.5) << endl;

  cout << "\nExpression 4" << endl;
  cout << "6  /  4 + 3.9 = " << (6 / 4 + 3.9) << endl;

  cout << "\nExpression 5" << endl;
  cout << "5.4  *  2 - 13.6 + 18  /  2 = "
    << (5.4 * 2 - 13.6 + 18 / 2) << endl;

  cout << "\nExpression 6" << endl;
  cout << "7 / 3 + 32 / 3 = " << (7 / 3 + 32 / 3) << endl;

  // Show implicit type conversion
  // 6 is implicitly converted to a real number and then 
  // added to 5.4
  cout << "\nImplicit type conversion: 6 + 5.4 = " 
    << (6 + 5.4) << endl;

  // Show explicit type conversion
  // 6 is explicitly converted to a real number and then 
  // added to 5.4
  cout << "\nExplicit type conversion: 6 + 5.4 = " 
    << ((double) 6 + 5.4) << endl;

  // Show application close
  cout << "\nEnd of Arithmetic Expressions" << endl;

}

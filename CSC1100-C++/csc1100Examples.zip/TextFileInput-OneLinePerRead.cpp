//==========================================================
//
// Title: Text file input - one line per read
// Description:
//   This C++ console application demonstrates reading one 
// line at a time from a text file.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const string INPUT_FILE_NAME = "USStatesIn.txt";

  // Declare variables
  ifstream inFile;
  int lineCount;
  string line;

  // Show application header
  cout << "Welcome to Text File Input - One Line Per Read" 
    << endl;
  cout << "----------------------------------------------" 
    << endl << endl;

  // Attempt to open input file
  inFile.open(INPUT_FILE_NAME);
  if (!inFile.is_open())
    cout << "Error: unable to open file '" 
      << INPUT_FILE_NAME << "'." << endl << endl;
  else 
  {

    // Loop to read from input file
    cout << "Reading lines from file '" << INPUT_FILE_NAME
      << "' ..." << endl << endl;
    lineCount = 0;
    while (inFile.good())
    {
      getline(inFile, line);
      cout << line << endl;
      lineCount = lineCount + 1;
    }

    // Close input file
    inFile.close();
    cout << endl << lineCount << " line(s) read from file '" 
      << INPUT_FILE_NAME << "'." << endl << endl;

  }

  // Show application close
  cout << "End of Text File Input - One Line Per Read" 
    << endl;

}

//==========================================================
//
// Title: Function Overloading
// Description:
//   This C++ console application demonstrates function 
// overloading.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// menuOption
//==========================================================
int menuOption()
{

  // Declare variables
  int option;

  // Show menu
  cout << "\nMeasure Menu" << endl;
  cout << "1 - Show distance" << endl;
  cout << "2 - Calculate and show area" << endl;
  cout << "3 - Calculate and show volume" << endl;
  cout << "9 - Exit" << endl;
  cout << "\nEnter an option: ";
  cin >> option;
  return option;

}

//==========================================================
// showMeasure (distance)
//==========================================================
void showMeasure(int d)
{
  cout << "The distance is " << d
    << (d == 1 ? " meter." : " meters.") << endl;
}

//==========================================================
// showMeasure (area)
//==========================================================
void showMeasure(int width, int length)
{
  int a = width * length;
  cout << "The area is " << a
    << (a == 1 ? " square meter." : " square meters.") 
    << endl;
}

//==========================================================
// showMeasure (volume)
//==========================================================
void showMeasure(int width, int length, int height)
{
  int v = width * length * height;
  cout << "The volume is " << v
    << (v == 1 ? " cubic meter." : " cubic meters.") 
    << endl;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int option;
  int distance;
  int width;
  int length;
  int height;

  // Show application header
  cout << "Welcome to Function Overloading" << endl;
  cout << "-------------------------------" << endl;

  // Loop to process menu options
  option = menuOption();
  while (option != 9)
  {

    // Test which option selected
    switch (option)
    {

      // Show distance
      case 1:
        cout << "\nEnter a distance (meters): ";
        cin >> distance;
        showMeasure(distance);
        break;

      // Calculate and show area
      case 2:
        cout << "\nEnter a width (meters): ";
        cin >> width;
        cout << "Enter a length (meters): ";
        cin >> length;
        showMeasure(width, length);
        break;

      // Calculate and show volume
      case 3:
        cout << "\nEnter a width (meters): ";
        cin >> width;
        cout << "Enter a length (meters): ";
        cin >> length;
        cout << "Enter a height (meters): ";
        cin >> height;
        showMeasure(width, length, height);
        break;

      // Handle unknown option
      default:
        cout << "Error: unknown option of " << option 
          << "." << endl;

    }

    // Show menu and get option
    option = menuOption();

  }

  // Show application close
  cout << "\nEnd of Function Overloading" << endl;

}

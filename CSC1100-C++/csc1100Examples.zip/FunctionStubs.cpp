//==========================================================
//
// Title: Function Stubs
// Description:
//   This C++ console application demonstrates function 
// stubs.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// showMenu
//==========================================================
void showMenu()
{
  cout << "\nRunning showMenu here ..." << endl;
}

//==========================================================
// areaCalculation
//==========================================================
double areaCalculation()
{
  cout << "Running areaCalculation here ... ";
  return -99;
}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  int option;
  
  // Show application header
  cout << "Welcome to Function Stubs" << endl;
  cout << "-------------------------" << endl;
  
  // Show menu and get option
  showMenu();
  cout << "\nEnter an option: ";
  cin >> option;

  // Loop to process menu options
  while (option != 9)
  {

    // Test which option selected
    switch (option)
    {

      // Option 1 here
      case 1: 
        cout << "Doing Option 1 here ..." << endl;
        break;

      // Option 2 here
      case 2:
        cout << "Doing Option 2 here ..." << endl;
        break;

      // Show floor area
      case 3:
        cout << "Doing Option 3 here ..." << endl;
        cout << areaCalculation() << endl;
        break;

      // Handle unknown option
      default:
        cout << "Error: unknown option of " << option 
          << "." << endl;

    }

    // Show menu and get option
    showMenu();
    cout << "\nEnter an option: ";
    cin >> option;

  }
  cout << "Done processing menu options." << endl;

  // Show application close
  cout << "\nEnd of Function Stubs" << endl;

}

//==========================================================
//
// Title: struct With Functions
// Description:
//   This C++ console application demonstrates a struct with
// functions.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int COLFMT = 24;
struct employee
{

  //--------------------------------------------------------
  // Fields
  //--------------------------------------------------------

  int ID;
  string firstName;
  string lastName;
  double hourlyRate;

  //--------------------------------------------------------
  // Functions
  //--------------------------------------------------------

  // Constructor with zero parameters
  employee()
  {
    cout << "Creating struct variable using "
      << "zero-parameter constructor ..." << endl;
    ID = -99;
    firstName = "(not set)";
    lastName = "(not set)";
    hourlyRate = 16;
  }

  // Constructor with one parameter
  employee(int inID)
  {
    cout << "Creating struct variable using "
      << "one-parameter constructor ..." << endl;
    ID = inID;
    firstName = "(not set)";
    lastName = "(not set)";
    hourlyRate = 31;
  }

  // getFirstLastName
  string getFirstLastName()
  {
    return firstName + " " + lastName;
  }

  // getLastFirstName
  string getLastFirstName()
  {
    return lastName + ", " + firstName;
  }

};

//==========================================================
// printEmployee
//==========================================================
void printEmployee(string variable, employee emp)
{
  cout << "Employee information (ID " << emp.ID << ")" 
    << endl;
  cout << setw(COLFMT) << left << "Variable:"
    << setw(COLFMT) << left << variable << endl
    << setw(COLFMT) << left << "First name:"
    << setw(COLFMT) << left << emp.firstName << endl
    << setw(COLFMT) << left << "Last name:"
    << setw(COLFMT) << left << emp.lastName << endl
    << setw(COLFMT) << left << "Hourly rate ($):"
    << setw(COLFMT) << left << emp.hourlyRate << endl 
    << endl;
}

//==========================================================
// setEmployee
//==========================================================
employee setEmployee()
{

  // Declare variables
  employee emp;

  // Prompt for and get employee data
  cout << "\nEnter employee ID: ";
  cin >> emp.ID;
  cout << "Enter employee first name: ";
  cin >> emp.firstName;
  cout << "Enter employee last name: ";
  cin >> emp.lastName;
  cout << "Enter employee hourly rate: ";
  cin >> emp.hourlyRate;
  cout << endl;
  return emp;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  employee emp1;  // Use zero-parameter consructor
  employee emp2(44);  // Use one-parameter consructor

  // Show application header
  cout << "\nWelcome to structs With Functions" << endl;
  cout << "---------------------------------" << endl;
  
  // Format financial numbers
  cout << fixed << setprecision(2);

  // Print employees after construction
  cout << "\nEmployee information after construction" 
    << endl << endl;
  printEmployee("emp1", emp1);
  printEmployee("emp2", emp2);

  // Set employee from assigned values
  cout
    << "Setting employee information from assignment statements ..."
    << endl << endl;
  emp1.ID = 513;
  emp1.firstName = "Sam";
  emp1.lastName = "Stocker";
  emp1.hourlyRate = 14.75;
  printEmployee("emp1", emp1);

  // Set employee from read values
  cout
    << "Setting employee information from user ..."
    << endl << endl;
  emp2 = setEmployee();
  printEmployee("emp2", emp2);

  // Print employee names
  cout
    << "Printing employee names from struct functions..."
    << endl;
  cout << "emp1 name (first last): " 
    << emp1.getFirstLastName() << endl;
  cout << "emp1 name (last, first): " 
    << emp1.getLastFirstName() << endl;

  // Show application close
  cout << "\nEnd of structs With Functions" << endl;

}

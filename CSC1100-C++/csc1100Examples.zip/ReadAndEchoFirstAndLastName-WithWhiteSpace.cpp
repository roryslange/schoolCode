//==========================================================
//
// Title: Read and Echo First and Last Name
// Description:
//   This C++ console application reads and echoes a first 
// and last name.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  string firstName;
  string lastName;

  // Show application header
  cout << "Welcome to Read and Echo First and Last Name" 
    << endl;
  cout << "--------------------------------------------" 
    << endl << endl;

  // Prompt for and get first name
  cout << "Enter the first name (no spaces): ";
  cin >> firstName;

  // Prompt for and get last name
  cout << "Enter the last name (no spaces): ";
  cin >> lastName;

  // Show full name
  cout << "\nFull name: " << firstName << " " << lastName 
    << endl;

  // Show application close
  cout << "\nEnd of Read and Echo First and Last Name"
    << endl;

}

//==========================================================
//
// Title: OpenMP Compare
// Description:
//   This C++ console application compares serial and 
// parallel execution of code.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
#include "omp.h"
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================

// Declare constants
const int ARRAY_SIZE = 10;
const int COLFMT1 = 14;
const int COLFMT2 = 10;

//==========================================================
// main
//==========================================================
int main()
{

  // Declare variables
  double arr[ARRAY_SIZE];
  double tStart;
  double tStop;
  double tSerial;
  double tParallel;

  // Set real number format
  cout << fixed << setprecision(8);

  // Show application header
  cout << "Welcome to OpenMP Compare" << endl;
  cout << "-------------------------" << endl << endl;

  // Run array initialization in serial mode
  tStart = omp_get_wtime();
  for (int i = 0; i < ARRAY_SIZE; i++)
    arr[i] = rand();
  tStop = omp_get_wtime();
  tSerial = tStop - tStart;

  // Run array initialization in parallel mode
  tStart = omp_get_wtime();
  #pragma omp parallel for
  for (int i = 0; i < ARRAY_SIZE; i++)
    arr[i] = rand();
  tStop = omp_get_wtime();
  tParallel = tStop - tStart;

  // Print results
  cout << setw(COLFMT1) << left << "Array size:"
    << setw(COLFMT2) << right << ARRAY_SIZE << endl;
  cout << "\nComputation times (seconds)" << endl;
  cout << setw(COLFMT1) << left << "Serial:"
    << setw(COLFMT2) << right << tSerial << endl;
  cout << setw(COLFMT1) << left << "Parallel:"
    << setw(COLFMT2) << right << tParallel << endl;
  cout << endl;
  cout << setw(COLFMT1) << left << "Speedup:"
    << setw(COLFMT2) << right << (tSerial / tParallel) << endl;

  // Show application close
  cout << "\nEnd of OpenMP Compare" << endl;

}
//==========================================================
//
// Title: Text file output
// Description:
//   This C++ console application demonstrates writing data
// to a text file.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare constants
  const string OUTPUT_FILE_NAME = "RandomNumbers.txt";
  const int RANDOMS = 30;
  const int COLFMT1 = 12;
  const int COLFMT2 = 14;

  // Declare variables
  int lineCount;
  ofstream outFile;

  // Show application header
  cout << "Welcome to Text File Output" << endl;
  cout << "---------------------------" << endl << endl;

  // Print function rand() range
  cout 
    << "Function rand() generates random number from 0 to " 
    << RAND_MAX << " (RAND_MAX)." << endl << endl;

  // Attempt to open output file
  outFile.open(OUTPUT_FILE_NAME);
  if (!outFile.is_open())
    cout << "Error: unable to open file '"
      << OUTPUT_FILE_NAME << "'." << endl << endl;
  else
  {

    // Print column headers
    outFile << setw(COLFMT1) << right << "Line Number"
      << setw(COLFMT2) << right << "Random Number" << endl;

    // Loop to write to output file
    cout << "Writing lines to file '" << OUTPUT_FILE_NAME
      << "' ..." << endl << endl;
    lineCount = 0;
    while (lineCount < RANDOMS)
    {
      lineCount = lineCount + 1;
      outFile << setw(COLFMT1) << right << lineCount
        << setw(COLFMT2) << right << rand() << endl;
    }

    // Close output file
    outFile.close();
    lineCount = lineCount + 1;  // Add line for column headers
    cout << lineCount << " line(s) written to file '"
      << OUTPUT_FILE_NAME << "'." << endl << endl;

  }

  // Show application close
  cout << "End of Text File Output" << endl;

}

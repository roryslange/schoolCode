//==========================================================
//
//  Title: Relational Operators
//  Description:
//   This C++ console application uses relational operators 
// to compare int, char, and string data types.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int iNum1;
  int iNum2;
  char ltr1;
  char ltr2;
  string str1;
  string str2;
  double rNum1;
  double rNum2;

  // Show application header
  cout << "Welcome to Relational Operators" << endl;
  cout << "-------------------------------" << endl;
  cout << "0 = false" << endl;
  cout << "1 = true" << endl << endl;

  //--------------------------------------------------------
  // Integer comparisons
  //--------------------------------------------------------
  
  // Prompt for and get two integers
  cout << "Integer comparison" << endl;
  cout << "Enter integer 1: ";
  cin >> iNum1;
  cout << "Enter integer 2: ";
  cin >> iNum2;

  // Compare and show two integers
  cout << endl;
  cout << "Integer 1: " << iNum1 << endl;
  cout << "Integer 2: " << iNum2 << endl;
  cout << "==         " << (iNum1 == iNum2) << endl;
  cout << "!=         " << (iNum1 != iNum2) << endl;
  cout << "<          " << (iNum1 < iNum2) << endl;
  cout << "<=         " << (iNum1 <= iNum2) << endl;
  cout << ">          " << (iNum1 > iNum2) << endl;
  cout << ">=         " << (iNum1 >= iNum2) << endl;

  //--------------------------------------------------------
  // Character comparisons
  //--------------------------------------------------------

  // Compare and show two char literals
  cout << "\nCharacter literal comparison" << endl;
  cout << endl;
  cout << "Char 1:    " << 'w' << endl;
  cout << "Char 2:    " << 'z' << endl;
  cout << "==         " << ('w' == 'z') << endl;
  cout << "!=         " << ('w' != 'z') << endl;
  cout << "<          " << ('w' < 'z') << endl;
  cout << "<=         " << ('w' <= 'z') << endl;
  cout << ">          " << ('w' > 'z') << endl;
  cout << ">=         " << ('w' >= 'z') << endl;

  // Prompt for and get two chars
  cout << "\nCharacter variable comparison" << endl;
  cout << "Enter char 1: ";
  cin >> ltr1;
  cout << "Enter char 2: ";
  cin >> ltr2;

  // Compare and show two chars
  cout << endl;
  cout << "Char 1:    " << ltr1 << endl;
  cout << "Char 2:    " << ltr2 << endl;
  cout << "==         " << (ltr1 == ltr2) << endl;
  cout << "!=         " << (ltr1 != ltr2) << endl;
  cout << "<          " << (ltr1 < ltr2) << endl;
  cout << "<=         " << (ltr1 <= ltr2) << endl;
  cout << ">          " << (ltr1 > ltr2) << endl;
  cout << ">=         " << (ltr1 >= ltr2) << endl;

  //--------------------------------------------------------
  // String comparisons
  //--------------------------------------------------------

  // Compare and show two string literals
  cout << "\nString literal-to-literal comparison" << endl;
  cout << "(Saular rule: this compares memory addresses, "
    << "not values)" << endl;
  cout << endl;
  cout << "String 1:  " << "'" << "wsu" << "'" << endl;
  cout << "String 2:  " << "'" << "msu" << "'" << endl;
  cout << "==         " << ("wsu" == "msu") << endl;
  cout << "!=         " << ("wsu" != "msu") << endl;
  cout << "<          " << ("wsu" < "msu") << endl;
  cout << "<=         " << ("wsu" <= "msu") << endl;
  cout << ">          " << ("wsu" > "msu") << endl;
  cout << ">=         " << ("wsu" >= "msu") << endl;

  // Prompt for and get two strings
  cout << "\nString variable-to-variable comparison" 
    << endl;
  cin.ignore(100, '\n'); 
    // This is required to scan past the ENTER character
  cout << "Enter string 1 (spaces allowed): ";
  getline(cin, str1);
  cout << "Enter string 2 (spaces allowed): ";
  getline(cin, str2);

  // Compare and show two strings
  cout << endl;
  cout << "String 1:  " << "'" << str1 << "'" << endl;
  cout << "String 2:  " << "'" << str2 << "'" << endl;
  cout << "==         " << (str1 == str2) << endl;
  cout << "!=         " << (str1 != str2) << endl;
  cout << "<          " << (str1 < str2) << endl;
  cout << "<=         " << (str1 <= str2) << endl;
  cout << ">          " << (str1 > str2) << endl;
  cout << ">=         " << (str1 >= str2) << endl;

  // Compare and show two strings
  cout << "\nString variable-to-literal comparison" << endl;
  str1 = "wsu";
  cout << "String 1:  " << "'" << str1 << "'" << endl;
  cout << "String 2:  " << "'" << "msu" << "'" << endl;
  cout << "==         " << (str1 == "msu") << endl;
  cout << "!=         " << (str1 != "msu") << endl;
  cout << "<          " << (str1 < "msu") << endl;
  cout << "<=         " << (str1 <= "msu") << endl;
  cout << ">          " << (str1 > "msu") << endl;
  cout << ">=         " << (str1 >= "msu") << endl;

  //--------------------------------------------------------
  // Real-number comparisons
  //--------------------------------------------------------

  // Compare real numbers
  cout << "\nReal-number equality" << endl;

  rNum1 = 1;
  rNum2 = 3 / 7. + 2 / 7. + 2 / 7.;

  cout << fixed << setprecision(20);

  cout << endl << "rNum1 is " << rNum1 << endl;
  cout << "rNum2 is " << rNum2 << endl;

  cout << endl << "Using ==, ";
  if (rNum1 == rNum2)
    cout << "rNum1 is equal to rNum2." << endl;
  else
    cout << "rNum1 is NOT equal to rNum2." << endl;

  cout << "Using < error margin of 0.001, ";
  if (abs(rNum1 - rNum2) < 0.001)
    cout << "rNum1 is equal to rNum2." << endl;
  else
    cout << "rNum1 is NOT equal to rNum2." << endl;

  // Show application close
  cout << "\nEnd of Relational Operators" << endl;

}

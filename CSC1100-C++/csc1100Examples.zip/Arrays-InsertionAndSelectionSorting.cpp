//==========================================================
//
// Title: Array Sorting
// Description:
//   This C++ console application demonstrates array sorting
// using the insertion and selection sort algorithms.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int ARRAY_SIZE = 5;
const int RANDOM_UPPER = 12;
const int COLFMT1 = 6;
const int COLFMT2 = 4;

//==========================================================
// randomizeArray
//==========================================================
void randomizeArray(int numArray[], int arrSize, 
  int upperLimit)
{

  // Initialize random number generator
  srand(time(NULL));

  // Loop to generate and store random numbers in array
  for (int i = 0; i < arrSize; i++)
    numArray[i] = rand() % upperLimit + 1;
  cout << "\nRandomized numbers in the range 1 to " 
     << upperLimit << " stored in array." << endl;

}

//==========================================================
// printArray
//==========================================================
void printArray(string heading, int numArray[], int arrSize)
{

  // Loop to print array numbers
  cout << "\n" + heading << endl;
  cout << "Array size: " << arrSize << endl;
  cout << setw(COLFMT1) << left << "Index"
    << setw(COLFMT1) << left << "Value" << endl;
  for (int i = 0; i < arrSize; i++)
    cout << setw(COLFMT1) << left << i
      << setw(COLFMT1) << left << numArray[i] << endl;

}

//==========================================================
// printArrayInLine
//==========================================================
void printArrayInLine(string heading, int loop, int arr[], 
  int arrSize)
{

  // Test which header to print
  if (loop == ARRAY_SIZE)
    cout << "\n" << heading << ":             ";
  else
    cout << "\n" << heading << loop << ": ";

  // Loop to print array numbers in line
  for (int i = 0; i < arrSize; i++)
  {
    if (loop == i)
      cout << "   /";
    cout << setw(COLFMT2) << right << arr[i];
  }

  // Test whether to print final slash
  if (loop == ARRAY_SIZE)
    cout << "   /";
  cout << endl;

}

//==========================================================
// insertionSortArray
//==========================================================
void insertionSortArray(int numArray[], int arrSize)
{

  // Declare variables
  int value;
  int spot;

  // Loop to test each value
  cout << "\nArray insertion sorting - "
    << "values to left of / are sorted." << endl;
  for (int i = 1; i < arrSize; i++)
  {

    // Loop to find spot to place value
    value = numArray[i];
    printArrayInLine("Sorting value at index ", i, numArray, arrSize);
    spot = i - 1;
    while (spot >= 0 && numArray[spot] > value)
    {
      numArray[spot + 1] = numArray[spot];
      spot = spot - 1;
    }

    // Place value in spot
    if (spot == i - 1)
      cout << "-Value NOT moved." << endl;
    else
    {
      numArray[spot + 1] = value;
      cout << "-Value moved to index " << spot + 1 << "." 
        << endl;
    }

  }
  printArrayInLine("End of loops", ARRAY_SIZE,
    numArray, ARRAY_SIZE);

}

//==========================================================
// selectionSortArray
//==========================================================
void selectionSortArray(int numArray[], int arrSize)
{

  // Declare variables
  int minIndex;
  int temp;

  // Loop to find min index within all groups
  cout << "\nArray selection sorting - "
    << "values to left of / are sorted." << endl;
  for (int i = 0; i < arrSize - 1; i++)
  {

    // Loop to find min index within one group
    printArrayInLine("Sorting value at index ", i,
      numArray, arrSize);
    minIndex = i;
    for (int j = i + 1; j < arrSize; j++)
    {
      if (numArray[j] < numArray[minIndex])
        minIndex = j;
    }

    // Test if swap needed
    if (minIndex == i)
      cout << "-Value NOT moved." << endl;
    else
    {
      temp = numArray[minIndex];
      numArray[minIndex] = numArray[i];
      numArray[i] = temp;
      cout << "-Indexes " << i << " and " << minIndex 
        << " swapped." << endl;
    }

  }
  printArrayInLine("End of loops", arrSize,
    numArray, arrSize);

}

//==========================================================
// main
//==========================================================
int main()
{
  
  // Declare variables
  int numArray[ARRAY_SIZE];

  // Show application header
  cout << "Welcome to Array Sorting" << endl;
  cout << "------------------------" << endl << endl;

  // Print sort heading
  cout << "------------------------------------------------------------"
    << endl;
  cout << "Insertion sort" << endl;
  cout << "------------------------------------------------------------"
    << endl;

  // Place random numbers in array
  randomizeArray(numArray, ARRAY_SIZE, RANDOM_UPPER);

  // Print array
  printArray("Array values before insertion sort", 
    numArray, ARRAY_SIZE);

  // Insertion sort array
  insertionSortArray(numArray, ARRAY_SIZE);

  // Print array
  printArray("Array values after insertion sort", 
    numArray, ARRAY_SIZE);

  // Print sort heading
  cout << "\n------------------------------------------------------------"
    << endl;
  cout << "Selection sort" << endl;
  cout << "------------------------------------------------------------"
    << endl;

  // Place random numbers in array
  randomizeArray(numArray, ARRAY_SIZE, RANDOM_UPPER);

  // Print array
  printArray("Array values before selection sort",
    numArray, ARRAY_SIZE);

  // Selection sort array
  selectionSortArray(numArray, ARRAY_SIZE);
  
  // Print array
  printArray("Array values after selection sort", 
    numArray, ARRAY_SIZE);

  // Show application close
  cout << "\nEnd of Array Sorting" << endl;

}

//==========================================================
//
// Title: OpenMP Test
// Description:
//   This C++ console application confirms that OpenMP 
// works.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
#include "omp.h"
using namespace std; // So "std::cout" may be abbreviated to "cout"

//==========================================================
// main
//==========================================================
int main()
{

  // Show application header
  cout << "Welcome to OpenMP Test" << endl;
  cout << "----------------------" << endl << endl;

  // Run fixed number of threads
  cout << "Maximum number of threads on this computer: " 
    << omp_get_max_threads() << endl;

  // Run fixed number of threads
  cout << "\nRunning a fixed number of threads ..." << endl;
  #pragma omp parallel num_threads(4)
  {
	  #pragma omp critical
    printf("Hello from thread %d of %d.\n",
      omp_get_thread_num(), omp_get_num_threads());
  }

  // Run default number of threads
  cout << "\nRunning a default number of threads ..." << endl;
  #pragma omp parallel 
  {
    #pragma omp critical
    printf("Hello from thread %d of %d.\n",
      omp_get_thread_num(), omp_get_num_threads());
  }

  // Show application close
  cout << "\nEnd of OpenMP Test" << endl << endl;

}
//==========================================================
//
// Title: cins
// Description:
//   This C++ console application shows various cin 
// functions.
//
//==========================================================
#include <cstdlib> // For several general-purpose functions
#include <fstream> // For file handling
#include <iomanip> // For formatted output
#include <iostream> // For cin, cout, and system
#include <string> // For string data type
using namespace std; // So "std::cout" may be abbreviated to "cout"

int main()
{

  // Declare variables
  int iNum;
  double rNum;
  char chr;
  string str;
  string line;

  // Show application header
  cout << "Welcome to cin Statements" << endl;
  cout << "-------------------------" << endl << endl;

  // Prompt for and get two integers
  cout << "Enter integer 1: ";
  cin >> iNum;
  cout << "Integer 1:                                " 
    << iNum << endl;
  cout << "Next input buffer character (ASCII code): " 
    << cin.peek() << endl;

  cout << endl;
  cout << "Enter integer 2: ";
  cin >> iNum;
  cout << "Integer 2:                                "
    << iNum << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  // Prompt for and get two real numbers
  cout << endl;
  cout << "Enter real-number 1: ";
  cin >> rNum;
  cout << "Real-number 1:                            "
    << rNum << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  cout << endl;
  cout << "Enter real-number 2: ";
  cin >> rNum;
  cout << "Real-number 2:                            "
    << rNum << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  // Prompt for and get two strings
  cout << endl;
  cout << "Enter string 1 (no spaces): ";
  cin >> str;
  cout << "String 1:                                 "
    << str << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  cout << endl;
  cout << "Enter string 2 (no spaces): ";
  cin >> str;
  cout << "String 2:                                 "
    << str << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  // Clear input buffer of ENTER character
  cin.ignore(1000, '\n');
  cout << endl;
  cout << "Input buffer cleared." << endl;

  // Prompt for and get two chars
  cout << endl;
  cout << "Enter char 1: ";
  cin.get(chr);
  cout << "Char 1:                                   "
    << chr << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  // Clear input buffer of ENTER character
  cin.ignore(100, '\n');
  cout << endl;
  cout << "Input buffer cleared." << endl;

  cout << endl;
  cout << "Enter char 2: ";
  cin.get(chr);
  cout << "Char 2:                                   "
    << chr << endl;
  cout << "Next input buffer character (ASCII code): "
    << cin.peek() << endl;

  // Clear input buffer of ENTER character
  cin.ignore(100, '\n');
  cout << endl;
  cout << "Input buffer cleared." << endl;

  // Prompt for and get two lines
  // getline clears input buffer so peek() can't be used 
  // after it
  cout << endl;
  cout << "Enter line 1: ";
  getline(cin, line);
  cout << "Line 1: '" << line << "'" << endl;

  cout << endl;
  cout << "Enter line 2: ";
  getline(cin, line);
  cout << "Line 2: '" << line << "'" << endl;

  // Show application close
  cout << "\nEnd of cin Statements" << endl;

}

//==========================================================
//
// Title: Arrays
// Description:
//   This C++ console application demonstrates arrays.
//
//==========================================================
#include <cstdlib>  // For several general-purpose functions
#include <fstream>  // For file handling
#include <iomanip>  // For formatted output
#include <iostream>  // For cin, cout, and system
#include <string>  // For string data type
using namespace std;  // So "std::cout" may be abbreviated to "cout"

//==========================================================
// Globals
//==========================================================
const int ARRAY_SIZE = 5;
const int COLFMT1 = 6;
const int COLFMT2 = 20;
const int LUKE_ARRAY[] = { 7, 13 };  // Luke array constant

//==========================================================
// randomizeArray
//==========================================================
void randomizeArray(string heading, int arr[], int arrSize,
  int upperLimit)
{

  // Initialize random number generator
  srand(time(NULL));

  // Loop to generate and store random numbers in array
  for (int i = 0; i < arrSize; i++)
    arr[i] = rand() % upperLimit + 1;
  cout << "\nRandomized numbers in the range 1 to " 
    << upperLimit << " stored in array " << heading << endl;

}

//==========================================================
// printArray
//==========================================================
void printArray(string heading, int arr[], int arrSize)
{

  // Loop to print array numbers
  cout << "\n" + heading << endl;
  cout << "Array size: " << arrSize << endl;
  cout << setw(COLFMT1) << left << "Index" 
    << setw(COLFMT1) << left << "Value" << endl;
  for (int i = 0; i < arrSize; i++)
    cout << setw(COLFMT1) << left << i 
      << setw(COLFMT1) << left << arr[i] << endl;

}

//==========================================================
// copyArray
//==========================================================
void copyArray(int arrSource[], int arrTarget[], 
  int arrSize)
{

  // Loop to copy array elements
  for (int i = 0; i < arrSize; i++)
    arrTarget[i] = arrSource[i];

}

//==========================================================
// arrayAsReturnType - cannot have array as return type
//==========================================================
//int[] arrayAsReturnType(int arrSource[], int arrSize)
//{
//
//  // Declare variables
//  int arrTarget[6];
//
//  // Loop to copy array elements
//  for (int i = 0; i < arrSize; i++)
//    arrTarget[i] = arrSource[i];
//
//  return arrTarget;
//
//}

//==========================================================
// readOnlyArray
//==========================================================
void readOnlyArray(const int arr[], const int arrSize)
{

  // Change array element
  //arr[0] = 5;
    // Cannot change array value since constant
  //arrSize = 7;

}

//==========================================================
// main
//==========================================================
int main()
{

  // Declare array variables

  int arr1[3];
    // Use integer for array size

  int arr2[ARRAY_SIZE];
    // Use constant for array size

  int arr3[ARRAY_SIZE * 2];
    // Use expression for array size

  int arr4[] = {2016, 2004, 2000, 1988, 1984, 1980};
    // Use initializer list

  int arr5[ARRAY_SIZE] = {1978, 2013};
    // Use partial initializer list

  // Declare other variables
  int x = 7;
  int y = 17;
  int arr6[] = { x, y };
    // Use Shubham's initializer list with variables

  //int size = 10;
  //int arr7[size];
  //  // Cannot define array size with a variable

  // Max space for all variables is ~0.5MB
  // int needs 4 bytes per value
  //int arr8[131072];

  // Declare other variables
  int arraySize;

  // Show application header
  cout << "Welcome to Arrays" << endl;
  cout << "-----------------" << endl;

  // Place random numbers in each array
  randomizeArray("arr1", arr1, 3, 10);
  randomizeArray("arr2", arr2, ARRAY_SIZE, 20);
  randomizeArray("arr3", arr3, ARRAY_SIZE * 2, 30);

  // Print numbers in each array
  printArray("arr1 values", arr1, 3);
  printArray("arr2 values", arr2, ARRAY_SIZE);
  printArray("arr3 values", arr3, ARRAY_SIZE * 2);

  // Print data past end of array
  //arr3[10] = 77;  // Can do this but generates run-time error at later time
  printArray(
    "arr3 values and beyond - out-of-bounds error not caught!", 
    arr3, ARRAY_SIZE * 4);

  // Print array declared with initializer list
  arraySize = sizeof(arr4) / sizeof(int);
  printArray("arr4 values", arr4, arraySize);

  // Print array declared with partial initializer list
  arraySize = sizeof(arr5) / sizeof(int);
  printArray("arr5 values", arr5, arraySize);

  // Print array declared with initializer list variables
  arraySize = sizeof(arr6) / sizeof(int);
  printArray("arr6 values", arr6, arraySize);

  // Loop to print array constant
  arraySize = sizeof(LUKE_ARRAY) / sizeof(int);
  cout << "\nArray constant values" << endl;
  cout << "Array size: " << arraySize << endl;
  cout << setw(COLFMT1) << left << "Index" 
    << setw(COLFMT1) << left << "Value" << endl;
  for (int i = 0; i < arraySize; i++)
    cout << setw(COLFMT1) << left << i 
      << setw(COLFMT1) << left << LUKE_ARRAY[i] << endl;

  // Copy arr2 to arr5
  cout << "\nCopying arr2 to arr5" << endl;
  printArray("arr2 before copy", arr2, ARRAY_SIZE);
  printArray("arr5 before copy", arr5, ARRAY_SIZE);
  copyArray(arr2, arr5, ARRAY_SIZE);
  printArray("arr5 after copy", arr5, ARRAY_SIZE);

  // Print array addresses
  cout << "\nArray info" << endl;
  cout << setw(COLFMT2) << left << "Name" 
    << setw(COLFMT2) << left << "Address (hex)"
    << setw(COLFMT2) << left << "Size" << endl;

  cout << setw(COLFMT2) << left << "arr1"
    << setw(COLFMT2) << left << arr1 
    << setw(COLFMT2) << left 
    << sizeof(arr1) / sizeof(int) << endl;

  cout << setw(COLFMT2) << left << "arr2"
    << setw(COLFMT2) << left << arr2
    << setw(COLFMT2) << left 
    << sizeof(arr2) / sizeof(int) << endl;

  cout << setw(COLFMT2) << left << "arr3"
    << setw(COLFMT2) << left << arr3 
    << setw(COLFMT2) << left 
    << sizeof(arr3) / sizeof(int) << endl;

  cout << setw(COLFMT2) << left << "arr4"
    << setw(COLFMT2) << left << arr4 
    << setw(COLFMT2) << left 
    << sizeof(arr4) / sizeof(int) << endl;

  cout << setw(COLFMT2) << left << "arr5"
    << setw(COLFMT2) << left << arr5 
    << setw(COLFMT2) << left 
    << sizeof(arr5) / sizeof(int) << endl;

  cout << setw(COLFMT2) << left << "arr6"
    << setw(COLFMT2) << left << arr6
    << setw(COLFMT2) << left
    << sizeof(arr6) / sizeof(int) << endl;

  // Show application close
  cout << "\nEnd of Arrays" << endl;

}
